"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { AIAssistant } from "@/components/ai-assistant"
import { useToast } from "@/hooks/use-toast"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import {
  ArrowUp,
  ArrowDown,
  DollarSign,
  TrendingUp,
  Users,
  Calendar,
  Share2,
  Target,
  Zap,
  Download,
  FileText,
  FileSpreadsheet,
} from "lucide-react"
import Link from "next/link"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface FinancialModel {
  companyName: string
  projections: {
    revenue: Array<{ month: string; value: number }>
    costs: Array<{ category: string; value: number }>
    metrics: {
      arr: number
      mrr: number
      cac: number
      ltv: number
      burnRate: number
      runway: number
      grossMargin: number
    }
  }
  scenarios: {
    conservative: any
    optimistic: any
    realistic: any
  }
}

export default function DashboardPage() {
  const [model, setModel] = useState<FinancialModel | null>(null)
  const [currentScenario, setCurrentScenario] = useState("realistic")
  const [scenarioParams, setScenarioParams] = useState({
    revenueGrowth: 20,
    churnRate: 5,
    cac: 100,
    conversionRate: 2,
  })
  const { toast } = useToast()

  useEffect(() => {
    // Load model data from localStorage or API
    const savedModel = localStorage.getItem("financialModel")
    if (savedModel) {
      setModel(JSON.parse(savedModel))
    } else {
      // Generate sample data for demo
      setModel({
        companyName: "Sample Startup",
        projections: {
          revenue: [
            { month: "Jan", value: 10000 },
            { month: "Feb", value: 15000 },
            { month: "Mar", value: 22000 },
            { month: "Apr", value: 33000 },
            { month: "May", value: 48000 },
            { month: "Jun", value: 70000 },
            { month: "Jul", value: 95000 },
            { month: "Aug", value: 125000 },
            { month: "Sep", value: 160000 },
            { month: "Oct", value: 200000 },
            { month: "Nov", value: 250000 },
            { month: "Dec", value: 310000 },
          ],
          costs: [
            { category: "Marketing", value: 45000 },
            { category: "Development", value: 80000 },
            { category: "Operations", value: 25000 },
            { category: "Sales", value: 35000 },
            { category: "General", value: 15000 },
          ],
          metrics: {
            arr: 1200000,
            mrr: 100000,
            cac: 150,
            ltv: 1200,
            burnRate: 50000,
            runway: 18,
            grossMargin: 75,
          },
        },
        scenarios: {
          conservative: {},
          optimistic: {},
          realistic: {},
        },
      })
    }
  }, [])

  const updateScenario = async () => {
    try {
      const response = await fetch("/api/scenario-plan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          modelId: "current",
          parameters: scenarioParams,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to update scenario")
      }

      const updatedModel = await response.json()
      setModel(updatedModel)

      toast({
        title: "Scenario Updated",
        description: "Your financial projections have been recalculated.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update scenario. Please try again.",
        variant: "destructive",
      })
    }
  }

  const exportModel = async (format: "pdf" | "excel" | "word") => {
    try {
      const response = await fetch("/api/export", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          modelId: "current",
          format,
          data: model,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to export model")
      }

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `financial-model.${format === "excel" ? "xlsx" : format === "word" ? "docx" : "pdf"}`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)

      toast({
        title: "Export Complete",
        description: `Your financial model has been exported as ${format.toUpperCase()}.`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export model. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (!model) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-8">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <Zap className="h-12 w-12 animate-spin mx-auto mb-4 text-primary" />
              <p className="text-lg">Loading your financial model...</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const COLORS = ["#0A84FF", "#FFD60A", "#34C759", "#FF3B30", "#AF52DE"]

  const MetricCard = ({ title, value, change, icon: Icon, format = "currency" }: any) => (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold">
              {format === "currency"
                ? `$${value.toLocaleString()}`
                : format === "percentage"
                  ? `${value}%`
                  : format === "months"
                    ? `${value} months`
                    : value.toLocaleString()}
            </p>
            {change && (
              <div className={`flex items-center text-sm ${change > 0 ? "text-green-600" : "text-red-600"}`}>
                {change > 0 ? <ArrowUp className="h-4 w-4 mr-1" /> : <ArrowDown className="h-4 w-4 mr-1" />}
                {Math.abs(change)}%
              </div>
            )}
          </div>
          <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon className="h-6 w-6 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">{model.companyName} Dashboard</h1>
            <p className="text-muted-foreground">Financial projections and scenario planning</p>
          </div>
          <div className="flex space-x-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => exportModel("pdf")}>
                  <FileText className="mr-2 h-4 w-4" />
                  Export as PDF
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => exportModel("excel")}>
                  <FileSpreadsheet className="mr-2 h-4 w-4" />
                  Export as Excel
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => exportModel("word")}>
                  <FileText className="mr-2 h-4 w-4" />
                  Export as Word
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button variant="outline" asChild>
              <Link href="/share-tools">
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Link>
            </Button>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="projections">Projections</TabsTrigger>
            <TabsTrigger value="scenarios">Scenarios</TabsTrigger>
            <TabsTrigger value="metrics">Metrics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="Annual Recurring Revenue"
                value={model.projections.metrics.arr}
                change={15}
                icon={DollarSign}
              />
              <MetricCard
                title="Monthly Recurring Revenue"
                value={model.projections.metrics.mrr}
                change={8}
                icon={TrendingUp}
              />
              <MetricCard
                title="Customer Acquisition Cost"
                value={model.projections.metrics.cac}
                change={-5}
                icon={Users}
              />
              <MetricCard title="Runway" value={model.projections.metrics.runway} icon={Calendar} format="months" />
            </div>

            {/* Revenue Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Revenue Forecast</CardTitle>
                <CardDescription>Monthly revenue projections for the next 12 months</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="chart-container">
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={model.projections.revenue}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, "Revenue"]} />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke="#0A84FF"
                        strokeWidth={3}
                        dot={{ fill: "#0A84FF", strokeWidth: 2, r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Cost Breakdown */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Cost Breakdown</CardTitle>
                  <CardDescription>Monthly operating expenses by category</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="chart-container">
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={model.projections.costs}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ category, percent }) => `${category} ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {model.projections.costs.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, "Cost"]} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Key Ratios</CardTitle>
                  <CardDescription>Important financial health indicators</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">LTV:CAC Ratio</span>
                    <Badge
                      variant={
                        model.projections.metrics.ltv / model.projections.metrics.cac >= 3 ? "default" : "destructive"
                      }
                    >
                      {(model.projections.metrics.ltv / model.projections.metrics.cac).toFixed(1)}:1
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Gross Margin</span>
                    <Badge variant="outline">{model.projections.metrics.grossMargin}%</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Monthly Burn Rate</span>
                    <Badge variant="outline">${model.projections.metrics.burnRate.toLocaleString()}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Break-even Point</span>
                    <Badge variant="outline">Month 14</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="projections" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Growth</CardTitle>
                  <CardDescription>Monthly revenue progression</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="chart-container">
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart data={model.projections.revenue}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, "Revenue"]} />
                        <Bar dataKey="value" fill="#0A84FF" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Market Opportunity</CardTitle>
                  <CardDescription>TAM, SAM, and SOM visualization</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="chart-container">
                    <ResponsiveContainer width="100%" height={400}>
                      <PieChart>
                        <Pie
                          data={[
                            { name: "TAM", value: 100, color: "#0A84FF" },
                            { name: "SAM", value: 25, color: "#FFD60A" },
                            { name: "SOM", value: 5, color: "#34C759" },
                          ]}
                          cx="50%"
                          cy="50%"
                          outerRadius={120}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, value }) => `${name}: ${value}B`}
                        >
                          <Cell fill="#0A84FF" />
                          <Cell fill="#FFD60A" />
                          <Cell fill="#34C759" />
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="scenarios" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Scenario Planning</CardTitle>
                <CardDescription>Adjust key parameters to see how they impact your projections</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Revenue Growth Rate (%)</label>
                      <Slider
                        value={[scenarioParams.revenueGrowth]}
                        onValueChange={(value) => setScenarioParams((prev) => ({ ...prev, revenueGrowth: value[0] }))}
                        max={100}
                        step={1}
                        className="w-full"
                      />
                      <div className="text-center text-sm text-muted-foreground mt-1">
                        {scenarioParams.revenueGrowth}%
                      </div>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Monthly Churn Rate (%)</label>
                      <Slider
                        value={[scenarioParams.churnRate]}
                        onValueChange={(value) => setScenarioParams((prev) => ({ ...prev, churnRate: value[0] }))}
                        max={20}
                        step={0.1}
                        className="w-full"
                      />
                      <div className="text-center text-sm text-muted-foreground mt-1">{scenarioParams.churnRate}%</div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Customer Acquisition Cost ($)</label>
                      <Slider
                        value={[scenarioParams.cac]}
                        onValueChange={(value) => setScenarioParams((prev) => ({ ...prev, cac: value[0] }))}
                        max={500}
                        step={5}
                        className="w-full"
                      />
                      <div className="text-center text-sm text-muted-foreground mt-1">${scenarioParams.cac}</div>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Conversion Rate (%)</label>
                      <Slider
                        value={[scenarioParams.conversionRate]}
                        onValueChange={(value) => setScenarioParams((prev) => ({ ...prev, conversionRate: value[0] }))}
                        max={10}
                        step={0.1}
                        className="w-full"
                      />
                      <div className="text-center text-sm text-muted-foreground mt-1">
                        {scenarioParams.conversionRate}%
                      </div>
                    </div>
                  </div>
                </div>

                <Button onClick={updateScenario} className="w-full">
                  <Target className="mr-2 h-4 w-4" />
                  Update Scenario
                </Button>
              </CardContent>
            </Card>

            {/* Scenario Comparison */}
            <Card>
              <CardHeader>
                <CardTitle>Scenario Comparison</CardTitle>
                <CardDescription>Compare different scenarios side by side</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-semibold text-green-600 mb-2">Conservative</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>12M Revenue:</span>
                        <span>$850K</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Runway:</span>
                        <span>24 months</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Break-even:</span>
                        <span>Month 18</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg border-primary">
                    <h3 className="font-semibold text-primary mb-2">Realistic</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>12M Revenue:</span>
                        <span>$1.2M</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Runway:</span>
                        <span>18 months</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Break-even:</span>
                        <span>Month 14</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <h3 className="font-semibold text-yellow-600 mb-2">Optimistic</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>12M Revenue:</span>
                        <span>$2.1M</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Runway:</span>
                        <span>15 months</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Break-even:</span>
                        <span>Month 10</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="metrics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <MetricCard
                title="Customer Lifetime Value"
                value={model.projections.metrics.ltv}
                change={12}
                icon={Users}
              />
              <MetricCard
                title="Gross Margin"
                value={model.projections.metrics.grossMargin}
                change={3}
                icon={TrendingUp}
                format="percentage"
              />
              <MetricCard title="Payback Period" value={8} icon={Calendar} format="months" />
              <MetricCard title="Net Revenue Retention" value={115} change={5} icon={TrendingUp} format="percentage" />
              <MetricCard title="Magic Number" value={1.2} change={8} icon={Target} format="number" />
              <MetricCard title="Rule of 40" value={45} change={7} icon={DollarSign} format="percentage" />
            </div>

            {/* Detailed Metrics Table */}
            <Card>
              <CardHeader>
                <CardTitle>Detailed Financial Metrics</CardTitle>
                <CardDescription>Comprehensive view of all key performance indicators</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2">Metric</th>
                        <th className="text-right py-2">Current</th>
                        <th className="text-right py-2">Target</th>
                        <th className="text-right py-2">Industry Avg</th>
                        <th className="text-right py-2">Status</th>
                      </tr>
                    </thead>
                    <tbody className="space-y-2">
                      <tr className="border-b">
                        <td className="py-2">LTV:CAC Ratio</td>
                        <td className="text-right">
                          {(model.projections.metrics.ltv / model.projections.metrics.cac).toFixed(1)}:1
                        </td>
                        <td className="text-right">3:1</td>
                        <td className="text-right">3.2:1</td>
                        <td className="text-right">
                          <Badge
                            variant={
                              model.projections.metrics.ltv / model.projections.metrics.cac >= 3
                                ? "default"
                                : "destructive"
                            }
                          >
                            {model.projections.metrics.ltv / model.projections.metrics.cac >= 3 ? "Good" : "Needs Work"}
                          </Badge>
                        </td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">Gross Margin</td>
                        <td className="text-right">{model.projections.metrics.grossMargin}%</td>
                        <td className="text-right">80%</td>
                        <td className="text-right">75%</td>
                        <td className="text-right">
                          <Badge variant="default">Excellent</Badge>
                        </td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">Monthly Churn</td>
                        <td className="text-right">3.2%</td>
                        <td className="text-right">2%</td>
                        <td className="text-right">5.6%</td>
                        <td className="text-right">
                          <Badge variant="secondary">Above Avg</Badge>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <AIAssistant
        context="financial dashboard and metrics analysis"
        placeholder="Ask me about your financial metrics, projections, or scenarios..."
      />
    </div>
  )
}
