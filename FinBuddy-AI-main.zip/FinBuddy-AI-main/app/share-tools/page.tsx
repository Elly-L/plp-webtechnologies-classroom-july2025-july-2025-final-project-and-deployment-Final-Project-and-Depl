"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { AIAssistant } from "@/components/ai-assistant"
import { SocialShareModal } from "@/components/social-share-modal"
import { useToast } from "@/hooks/use-toast"
import {
  Download,
  Share2,
  Link2,
  FileText,
  Shield,
  Copy,
  Mail,
  Eye,
  Lock,
  Globe,
  Calendar,
  CheckCircle,
} from "lucide-react"

export default function ShareToolsPage() {
  const [shareSettings, setShareSettings] = useState({
    isPublic: false,
    requirePassword: false,
    password: "",
    expiresAt: "",
    allowComments: true,
    showContactInfo: true,
  })
  const [shareUrl, setShareUrl] = useState("")
  const [isGeneratingLink, setIsGeneratingLink] = useState(false)
  const [isExporting, setIsExporting] = useState(false)
  const [blockchainVerified, setBlockchainVerified] = useState(false)
  const [showSocialModal, setShowSocialModal] = useState(false)
  const { toast } = useToast()

  const generateShareLink = async () => {
    setIsGeneratingLink(true)
    try {
      const response = await fetch("/api/share-link", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          modelId: "current",
          settings: shareSettings,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate share link")
      }

      const data = await response.json()
      setShareUrl(data.shareUrl)
      setShowSocialModal(true) // Show social sharing modal

      toast({
        title: "Share Link Generated",
        description: "Your financial model is now ready to share.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate share link. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGeneratingLink(false)
    }
  }

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast({
        title: "Copied!",
        description: "Link copied to clipboard.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard.",
        variant: "destructive",
      })
    }
  }

  const exportModel = async (format: "pdf" | "excel" | "png") => {
    setIsExporting(true)
    try {
      const response = await fetch("/api/export", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          modelId: "current",
          format,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to export model")
      }

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `financial-model.${format}`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)

      toast({
        title: "Export Complete",
        description: `Your financial model has been exported as ${format.toUpperCase()}.`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export model. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
    }
  }

  const verifyOnBlockchain = async () => {
    try {
      const response = await fetch("/api/model-hash", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          modelId: "current",
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to verify on blockchain")
      }

      const data = await response.json()
      setBlockchainVerified(true)

      toast({
        title: "Blockchain Verified",
        description: `Transaction hash: ${data.transactionHash}`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to verify on blockchain. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Share & Export</h1>
            <p className="text-muted-foreground">
              Share your financial model with investors or export for presentations
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Export Options */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Download className="h-5 w-5" />
                    Export Options
                  </CardTitle>
                  <CardDescription>Download your financial model in various formats</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button
                    onClick={() => exportModel("pdf")}
                    disabled={isExporting}
                    className="w-full justify-start"
                    variant="outline"
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    Export as PDF
                    <Badge variant="secondary" className="ml-auto">
                      Investor Ready
                    </Badge>
                  </Button>

                  <Button
                    onClick={() => exportModel("excel")}
                    disabled={isExporting}
                    className="w-full justify-start"
                    variant="outline"
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    Export as Excel
                    <Badge variant="secondary" className="ml-auto">
                      Editable
                    </Badge>
                  </Button>

                  <Button
                    onClick={() => exportModel("png")}
                    disabled={isExporting}
                    className="w-full justify-start"
                    variant="outline"
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    Export as PNG
                    <Badge variant="secondary" className="ml-auto">
                      Visual
                    </Badge>
                  </Button>
                </CardContent>
              </Card>

              {/* Blockchain Verification */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Blockchain Verification
                  </CardTitle>
                  <CardDescription>Verify your model's authenticity on the blockchain</CardDescription>
                </CardHeader>
                <CardContent>
                  {blockchainVerified ? (
                    <div className="flex items-center gap-2 p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <div>
                        <p className="font-medium text-green-800 dark:text-green-200">Verified on Blockchain</p>
                        <p className="text-sm text-green-600 dark:text-green-400">
                          Your model is cryptographically secured
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        Add an immutable timestamp and hash of your financial model to the blockchain for verification
                        purposes.
                      </p>
                      <Button onClick={verifyOnBlockchain} className="w-full">
                        <Shield className="mr-2 h-4 w-4" />
                        Verify on Blockchain
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Share Settings */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Share2 className="h-5 w-5" />
                    Share Settings
                  </CardTitle>
                  <CardDescription>Configure how others can access your financial model</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Public Access</Label>
                      <p className="text-sm text-muted-foreground">Allow anyone with the link to view</p>
                    </div>
                    <Switch
                      checked={shareSettings.isPublic}
                      onCheckedChange={(checked) => setShareSettings((prev) => ({ ...prev, isPublic: checked }))}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Password Protection</Label>
                      <p className="text-sm text-muted-foreground">Require password to access</p>
                    </div>
                    <Switch
                      checked={shareSettings.requirePassword}
                      onCheckedChange={(checked) => setShareSettings((prev) => ({ ...prev, requirePassword: checked }))}
                    />
                  </div>

                  {shareSettings.requirePassword && (
                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <Input
                        id="password"
                        type="password"
                        value={shareSettings.password}
                        onChange={(e) => setShareSettings((prev) => ({ ...prev, password: e.target.value }))}
                        placeholder="Enter password"
                      />
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="expires">Expiration Date (Optional)</Label>
                    <Input
                      id="expires"
                      type="date"
                      value={shareSettings.expiresAt}
                      onChange={(e) => setShareSettings((prev) => ({ ...prev, expiresAt: e.target.value }))}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Allow Comments</Label>
                      <p className="text-sm text-muted-foreground">Let viewers leave feedback</p>
                    </div>
                    <Switch
                      checked={shareSettings.allowComments}
                      onCheckedChange={(checked) => setShareSettings((prev) => ({ ...prev, allowComments: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Show Contact Info</Label>
                      <p className="text-sm text-muted-foreground">Display your contact information</p>
                    </div>
                    <Switch
                      checked={shareSettings.showContactInfo}
                      onCheckedChange={(checked) => setShareSettings((prev) => ({ ...prev, showContactInfo: checked }))}
                    />
                  </div>

                  <Button onClick={generateShareLink} disabled={isGeneratingLink} className="w-full">
                    <Link2 className="mr-2 h-4 w-4" />
                    {isGeneratingLink ? "Generating..." : "Generate Share Link"}
                  </Button>
                </CardContent>
              </Card>

              {/* Generated Share Link */}
              {shareUrl && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Link2 className="h-5 w-5" />
                      Share Link
                    </CardTitle>
                    <CardDescription>Your financial model is ready to share</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Input value={shareUrl} readOnly className="flex-1" />
                      <Button size="icon" variant="outline" onClick={() => copyToClipboard(shareUrl)}>
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => window.open(shareUrl, "_blank")}>
                        <Eye className="mr-2 h-4 w-4" />
                        Preview
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          window.open(
                            `mailto:?subject=Financial Model&body=Check out my financial model: ${shareUrl}`,
                            "_blank",
                          )
                        }
                      >
                        <Mail className="mr-2 h-4 w-4" />
                        Email
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => setShowSocialModal(true)}>
                        <Share2 className="mr-2 h-4 w-4" />
                        Share
                      </Button>
                    </div>

                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      {shareSettings.isPublic ? (
                        <>
                          <Globe className="h-4 w-4" />
                          Public access
                        </>
                      ) : (
                        <>
                          <Lock className="h-4 w-4" />
                          Private access
                        </>
                      )}
                      {shareSettings.expiresAt && (
                        <>
                          <span>•</span>
                          <Calendar className="h-4 w-4" />
                          Expires {new Date(shareSettings.expiresAt).toLocaleDateString()}
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Social Share Modal */}
      <SocialShareModal
        isOpen={showSocialModal}
        onClose={() => setShowSocialModal(false)}
        shareUrl={shareUrl}
        companyName="Your Company"
      />

      <AIAssistant
        context="sharing and exporting financial models"
        placeholder="Ask me about sharing options, export formats, or blockchain verification..."
      />
    </div>
  )
}
