import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { slug: string } }) {
  try {
    const { slug } = params

    // In a real app, you would fetch the model from a database
    // For demo purposes, we'll return mock data

    const sharedModel = {
      id: slug,
      companyName: "TechStart Inc.",
      description:
        "AI-powered customer service platform helping businesses automate support and improve customer satisfaction through intelligent chatbots and workflow automation.",
      createdAt: "2024-01-15T10:30:00Z",
      author: {
        name: "Sarah Chen",
        email: "sarah@techstart.com",
        company: "TechStart Inc.",
      },
      projections: {
        revenue: [
          { month: "Jan", value: 15000 },
          { month: "Feb", value: 22000 },
          { month: "Mar", value: 33000 },
          { month: "Apr", value: 48000 },
          { month: "May", value: 70000 },
          { month: "Jun", value: 95000 },
          { month: "Jul", value: 125000 },
          { month: "Aug", value: 160000 },
          { month: "Sep", value: 200000 },
          { month: "Oct", value: 250000 },
          { month: "Nov", value: 310000 },
          { month: "Dec", value: 380000 },
        ],
        costs: [
          { category: "Marketing", value: 45000 },
          { category: "Development", value: 80000 },
          { category: "Operations", value: 25000 },
          { category: "Sales", value: 35000 },
          { category: "General", value: 15000 },
        ],
        metrics: {
          arr: 1500000,
          mrr: 125000,
          cac: 180,
          ltv: 1440,
          burnRate: 55000,
          runway: 20,
          grossMargin: 78,
        },
      },
      settings: {
        allowComments: true,
        showContactInfo: true,
      },
      isVerified: true,
    }

    return NextResponse.json(sharedModel)
  } catch (error) {
    console.error("Shared model fetch error:", error)
    return NextResponse.json({ error: "Model not found" }, { status: 404 })
  }
}
