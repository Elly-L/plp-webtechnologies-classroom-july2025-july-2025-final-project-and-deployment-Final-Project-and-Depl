import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { message, context, history: rawHistory, action } = await request.json()
    const history = Array.isArray(rawHistory) ? rawHistory : [];

    // Handle specific actions like market data lookup
    if (action === "get_market_size") {
      const marketData = getMarketSizeData(context)
      return NextResponse.json({ response: marketData, action: "prefill" })
    }

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer 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`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://finbuddy-ai.vercel.app",
        "X-Title": "FinBuddy AI",
      },
      body: JSON.stringify({
        model: "baidu/ernie-4.5-300b-a47b",
        messages: [
          {
            role: "system",
            content: `You are FinBuddy AI, a concise and helpful financial modeling assistant for startup founders.

**CORE RULES:**
1. **Answer ONLY what is asked** - don't provide unsolicited advice
2. **Be concise** - keep responses under 100 words unless specifically asked for details
3. **Direct responses** - if asked to enhance text, provide the enhanced version directly
4. **No lengthy guides** - avoid step-by-step instructions unless requested

**Response Types:**
- **Simple questions**: Give direct, brief answers
- **Text enhancement**: Return only the improved version
- **Market data**: Provide specific numbers with sources
- **Explanations**: Keep under 50 words with key points only

**Tone**: Friendly but brief, like a knowledgeable colleague giving quick help.

Current context: ${context}

Remember: Answer what's asked, nothing more. Be helpful but concise.`,
          },
          ...history.slice(-2).map((msg: any) => ({
            role: msg.role,
            content: msg.content,
          })),
          {
            role: "user",
            content: message,
          },
        ],
        temperature: 0.3,
        max_tokens: 200,
        stream: false,
      }),
    })

    if (!response.ok) {
      throw new Error("Failed to get AI response")
    }

    const data = await response.json()
    const aiResponse = data.choices[0]?.message?.content || "I'm having trouble right now. Please try again."

    return NextResponse.json({ response: aiResponse })
  } catch (error) {
    console.error("AI Assistant error:", error)
    return NextResponse.json(
      {
        response: "I'm having connection issues. Please try again!",
      },
      { status: 200 },
    )
  }
}

// Market size data lookup function
function getMarketSizeData(industry: string): string {
  const marketData: Record<string, any> = {
    edtech: {
      tam: 377,
      unit: "billions",
      description: "Global EdTech market size in 2024, growing at 13.4% CAGR",
    },
    fintech: {
      tam: 340,
      unit: "billions",
      description: "Global FinTech market size in 2024, growing at 16.8% CAGR",
    },
    healthtech: {
      tam: 659,
      unit: "billions",
      description: "Global HealthTech market size in 2024, growing at 12.6% CAGR",
    },
    saas: {
      tam: 195,
      unit: "billions",
      description: "Global SaaS market size in 2024, growing at 18.7% CAGR",
    },
    ecommerce: {
      tam: 6.2,
      unit: "trillions",
      description: "Global E-commerce market size in 2024, growing at 14.7% CAGR",
    },
  }

  const key = industry.toLowerCase().replace(/[^a-z]/g, "")
  const data = marketData[key] || marketData.saas

  return `${data.tam} ${data.unit} - ${data.description}`
}
