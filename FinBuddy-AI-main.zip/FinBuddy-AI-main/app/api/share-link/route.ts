import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { modelId, settings } = await request.json()

    // Generate a unique share ID
    const shareId = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)

    // In a real app, you would save the model and settings to a database
    // For demo purposes, we'll create a mock share URL

    const baseUrl = "https://finbuddy-ai.netlify.app"
    const shareUrl = `${baseUrl}/shared/${shareId}`

    // Mock response with share data
    const shareData = {
      shareUrl,
      shareId,
      settings,
      createdAt: new Date().toISOString(),
      expiresAt: settings.expiresAt || null,
      isPublic: settings.isPublic,
      requirePassword: settings.requirePassword,
      password: settings.password,
      allowComments: settings.allowComments,
      showContactInfo: settings.showContactInfo,
    }

    return NextResponse.json(shareData)
  } catch (error) {
    console.error("Share link generation error:", error)
    return NextResponse.json({ error: "Failed to generate share link" }, { status: 500 })
  }
}
