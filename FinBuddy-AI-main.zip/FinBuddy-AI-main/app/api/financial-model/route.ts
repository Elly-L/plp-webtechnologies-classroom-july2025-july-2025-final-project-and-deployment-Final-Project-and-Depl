import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.json()

    // Compose a prompt for the AI
    const prompt = `You are a financial modeling assistant. Based on the following startup data, generate:
- 12-month monthly revenue projections (array of objects: month, value)
- Cost breakdown (array of objects: category, value)
- Key metrics: ARR, MRR, CAC, LTV, Burn Rate, Runway, Gross Margin

Startup Data:
${JSON.stringify(formData, null, 2)}

Return ONLY a valid JSON object with this structure:
{
  "revenue": [ { "month": "Jan", "value": 10000 }, ... ],
  "costs": [ { "category": "Marketing", "value": 5000 }, ... ],
  "metrics": { "arr": 120000, "mrr": 10000, "cac": 150, "ltv": 1200, "burnRate": 50000, "runway": 18, "grossMargin": 75 }
}`;

    let aiData = null;
    try {
      const aiResponse = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer 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`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://finbuddy-ai.vercel.app",
          "X-Title": "FinBuddy AI",
        },
        body: JSON.stringify({
          model: "baidu/ernie-4.5-300b-a47b",
          messages: [
            {
              role: "system",
              content: "You are a concise and helpful financial modeling assistant for startup founders. Always return only valid JSON as requested.",
            },
            {
              role: "user",
              content: prompt,
            },
          ],
          temperature: 0.3,
          max_tokens: 600,
          stream: false,
        }),
      });
      if (aiResponse.ok) {
        const aiJson = await aiResponse.json();
        // Try to parse the JSON from the AI's response
        const match = aiJson.choices[0]?.message?.content.match(/\{[\s\S]*\}/);
        if (match) {
          aiData = JSON.parse(match[0]);
        }
      }
    } catch (err) {
      // If AI call fails, fallback to simulation
      aiData = null;
    }

    let revenue, costs, metrics;
    if (aiData && aiData.revenue && aiData.costs && aiData.metrics) {
      revenue = aiData.revenue;
      costs = aiData.costs;
      metrics = aiData.metrics;
    } else {
      // Fallback: previous simulation logic
      const monthlyGrowthRate = 0.15;
      const baseRevenue = formData.pricing * 100;
      revenue = [];
      for (let i = 0; i < 12; i++) {
        const monthRevenue = baseRevenue * Math.pow(1 + monthlyGrowthRate, i);
        revenue.push({
          month: new Date(2024, i).toLocaleString("default", { month: "short" }),
          value: Math.round(monthRevenue),
        });
      }
      costs = [
        { category: "Marketing", value: formData.cac * 50 },
        { category: "Development", value: formData.burnRate * 0.4 },
        { category: "Operations", value: formData.burnRate * 0.2 },
        { category: "Sales", value: formData.burnRate * 0.25 },
        { category: "General", value: formData.burnRate * 0.15 },
      ];
      const finalMonthRevenue = revenue[11].value;
      const arr = finalMonthRevenue * 12;
      const mrr = finalMonthRevenue;
      metrics = {
        arr,
        mrr,
        cac: formData.cac,
        ltv: formData.ltv,
        burnRate: formData.burnRate,
        runway: formData.runway,
        grossMargin: formData.grossMargin,
      };
    }

    const model = {
      id: `model_${Date.now()}`,
      companyName: formData.companyName,
      createdAt: new Date().toISOString(),
      projections: {
        revenue,
        costs,
        metrics,
      },
      scenarios: {
        conservative: {
          revenue: revenue.map((r) => ({ ...r, value: Math.round(r.value * 0.8) })),
        },
        optimistic: {
          revenue: revenue.map((r) => ({ ...r, value: Math.round(r.value * 1.5) })),
        },
        realistic: {
          revenue,
        },
      },
      formData,
    };

    return NextResponse.json(model);
  } catch (error) {
    console.error("Financial model generation error:", error);
    return NextResponse.json({ error: "Failed to generate financial model" }, { status: 500 });
  }
}
