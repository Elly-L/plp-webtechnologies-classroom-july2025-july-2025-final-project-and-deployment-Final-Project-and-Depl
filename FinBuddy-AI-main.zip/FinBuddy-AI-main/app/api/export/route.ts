import { type NextRequest, NextResponse } from "next/server"
import { jsPDF } from "jspdf"

export async function POST(request: NextRequest) {
  try {
    const { modelId, format, data } = await request.json()

    if (format === "pdf") {
      // Create investor-ready PDF
      const doc = new jsPDF()

      // Set up colors and fonts
      const primaryColor = [10, 132, 255] // Blue
      const secondaryColor = [100, 100, 100] // Gray
      const accentColor = [52, 199, 89] // Green

      // Title Page
      doc.setFontSize(28)
      doc.setTextColor(...primaryColor)
      doc.text(`${data.companyName || "Financial Model"}`, 20, 40)

      doc.setFontSize(16)
      doc.setTextColor(...secondaryColor)
      doc.text("Financial Projections & Business Model", 20, 55)

      doc.setFontSize(12)
      doc.text(`Generated on ${new Date().toLocaleDateString()}`, 20, 70)

      // Add logo placeholder
      doc.setDrawColor(...primaryColor)
      doc.rect(150, 20, 40, 40)
      doc.setFontSize(10)
      doc.text("LOGO", 165, 43)

      // Executive Summary Section
      doc.addPage()
      doc.setFontSize(20)
      doc.setTextColor(...primaryColor)
      doc.text("Executive Summary", 20, 30)

      // Key Metrics Cards
      let yPos = 50
      const metrics = [
        {
          label: "Annual Recurring Revenue",
          value: `$${data.projections?.metrics?.arr?.toLocaleString() || "0"}`,
          color: accentColor,
        },
        {
          label: "Monthly Recurring Revenue",
          value: `$${data.projections?.metrics?.mrr?.toLocaleString() || "0"}`,
          color: primaryColor,
        },
        {
          label: "Customer Acquisition Cost",
          value: `$${data.projections?.metrics?.cac?.toLocaleString() || "0"}`,
          color: secondaryColor,
        },
        {
          label: "Customer Lifetime Value",
          value: `$${data.projections?.metrics?.ltv?.toLocaleString() || "0"}`,
          color: accentColor,
        },
      ]

      metrics.forEach((metric, index) => {
        const xPos = 20 + (index % 2) * 90
        const yOffset = Math.floor(index / 2) * 35

        // Draw metric card background
        doc.setFillColor(245, 245, 245)
        doc.rect(xPos, yPos + yOffset, 85, 30, "F")

        // Draw colored accent bar
        doc.setFillColor(...metric.color)
        doc.rect(xPos, yPos + yOffset, 3, 30, "F")

        // Add metric text
        doc.setFontSize(10)
        doc.setTextColor(...secondaryColor)
        doc.text(metric.label, xPos + 8, yPos + yOffset + 12)

        doc.setFontSize(14)
        doc.setTextColor(0, 0, 0)
        doc.text(metric.value, xPos + 8, yPos + yOffset + 22)
      })

      // Revenue Chart Section
      yPos += 90
      doc.setFontSize(16)
      doc.setTextColor(...primaryColor)
      doc.text("Revenue Forecast", 20, yPos)

      // Draw simple chart representation
      if (data.projections?.revenue) {
        const chartData = data.projections.revenue.slice(0, 6) // First 6 months
        const chartWidth = 160
        const chartHeight = 60
        const barWidth = chartWidth / chartData.length

        // Chart background
        doc.setFillColor(250, 250, 250)
        doc.rect(20, yPos + 10, chartWidth, chartHeight, "F")

        // Draw bars
        const maxValue = Math.max(...chartData.map((d) => d.value))
        chartData.forEach((item, index) => {
          const barHeight = (item.value / maxValue) * (chartHeight - 10)
          const xPos = 20 + index * barWidth + 5
          const barYPos = yPos + 10 + (chartHeight - barHeight - 5)

          doc.setFillColor(...primaryColor)
          doc.rect(xPos, barYPos, barWidth - 10, barHeight, "F")

          // Month labels
          doc.setFontSize(8)
          doc.setTextColor(...secondaryColor)
          doc.text(item.month, xPos + 2, yPos + chartHeight + 20)

          // Value labels
          doc.text(`$${(item.value / 1000).toFixed(0)}K`, xPos, barYPos - 2)
        })
      }

      // Financial Ratios Section
      doc.addPage()
      doc.setFontSize(20)
      doc.setTextColor(...primaryColor)
      doc.text("Key Financial Ratios", 20, 30)

      yPos = 50
      const ratios = [
        {
          label: "LTV:CAC Ratio",
          value: data.projections?.metrics
            ? `${(data.projections.metrics.ltv / data.projections.metrics.cac).toFixed(1)}:1`
            : "N/A",
          status:
            data.projections?.metrics && data.projections.metrics.ltv / data.projections.metrics.cac >= 3
              ? "Healthy"
              : "Needs Improvement",
          target: "3:1 or higher",
        },
        {
          label: "Gross Margin",
          value: `${data.projections?.metrics?.grossMargin || 0}%`,
          status: (data.projections?.metrics?.grossMargin || 0) >= 70 ? "Excellent" : "Good",
          target: "70%+",
        },
        {
          label: "Monthly Burn Rate",
          value: `$${data.projections?.metrics?.burnRate?.toLocaleString() || "0"}`,
          status: "Tracking",
          target: "Minimize",
        },
        {
          label: "Runway",
          value: `${data.projections?.metrics?.runway || 0} months`,
          status: (data.projections?.metrics?.runway || 0) >= 12 ? "Safe" : "Critical",
          target: "12+ months",
        },
      ]

      ratios.forEach((ratio, index) => {
        const yOffset = index * 25

        // Ratio name
        doc.setFontSize(12)
        doc.setTextColor(0, 0, 0)
        doc.text(ratio.label, 20, yPos + yOffset)

        // Current value
        doc.setFontSize(14)
        doc.setTextColor(...primaryColor)
        doc.text(ratio.value, 80, yPos + yOffset)

        // Status indicator
        const statusColor =
          ratio.status === "Healthy" || ratio.status === "Excellent" || ratio.status === "Safe"
            ? accentColor
            : [255, 149, 0]
        doc.setFillColor(...statusColor)
        doc.circle(130, yPos + yOffset - 3, 3, "F")

        doc.setFontSize(10)
        doc.setTextColor(...statusColor)
        doc.text(ratio.status, 140, yPos + yOffset)

        // Target
        doc.setTextColor(...secondaryColor)
        doc.text(`Target: ${ratio.target}`, 140, yPos + yOffset + 8)
      })

      // Market Opportunity Section
      doc.addPage()
      doc.setFontSize(20)
      doc.setTextColor(...primaryColor)
      doc.text("Market Opportunity", 20, 30)

      // TAM/SAM/SOM visualization
      yPos = 60
      const marketSizes = [
        { label: "TAM (Total Addressable Market)", value: 100, color: [10, 132, 255, 0.3] },
        { label: "SAM (Serviceable Addressable Market)", value: 25, color: [255, 214, 10, 0.7] },
        { label: "SOM (Serviceable Obtainable Market)", value: 5, color: [52, 199, 89, 1] },
      ]

      const centerX = 105
      const centerY = yPos + 40

      marketSizes.forEach((market, index) => {
        const radius = 30 - index * 8
        doc.setFillColor(market.color[0], market.color[1], market.color[2])
        doc.circle(centerX, centerY, radius, "F")

        // Labels
        doc.setFontSize(10)
        doc.setTextColor(0, 0, 0)
        doc.text(market.label, 20, yPos + 100 + index * 15)
        doc.text(`${market.value}B Market`, 120, yPos + 100 + index * 15)
      })

      // Footer on each page
      const pageCount = doc.internal.getNumberOfPages()
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i)
        doc.setFontSize(8)
        doc.setTextColor(...secondaryColor)
        doc.text(`${data.companyName || "Financial Model"} - Confidential`, 20, 285)
        doc.text(`Page ${i} of ${pageCount}`, 180, 285)
      }

      const pdfBuffer = doc.output("arraybuffer")

      return new NextResponse(pdfBuffer, {
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition": 'attachment; filename="financial-model.pdf"',
        },
      })
    }

    if (format === "excel") {
      // Create Excel-like CSV for now (you could use a proper Excel library)
      const csvContent = `Financial Model - ${data.companyName || "Startup"}
      
Metric,Value,Unit
Annual Recurring Revenue,${data.projections?.metrics?.arr || 0},USD
Monthly Recurring Revenue,${data.projections?.metrics?.mrr || 0},USD
Customer Acquisition Cost,${data.projections?.metrics?.cac || 0},USD
Customer Lifetime Value,${data.projections?.metrics?.ltv || 0},USD
Gross Margin,${data.projections?.metrics?.grossMargin || 0},%
Monthly Burn Rate,${data.projections?.metrics?.burnRate || 0},USD
Runway,${data.projections?.metrics?.runway || 0},Months

Revenue Projections
Month,Revenue
${data.projections?.revenue?.map((r) => `${r.month},${r.value}`).join("\n") || ""}

Cost Breakdown
Category,Amount
${data.projections?.costs?.map((c) => `${c.category},${c.value}`).join("\n") || ""}
`

      return new NextResponse(csvContent, {
        headers: {
          "Content-Type": "text/csv",
          "Content-Disposition": 'attachment; filename="financial-model.csv"',
        },
      })
    }

    return NextResponse.json({ error: "Unsupported format" }, { status: 400 })
  } catch (error) {
    console.error("Export error:", error)
    return NextResponse.json({ error: "Failed to export model" }, { status: 500 })
  }
}
