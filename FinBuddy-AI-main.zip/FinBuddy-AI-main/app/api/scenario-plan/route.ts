import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { modelId, parameters } = await request.json()

    // Simulate scenario planning calculations
    // In a real app, this would recalculate projections based on new parameters

    const { revenueGrowth, churnRate, cac, conversionRate } = parameters

    // Recalculate projections based on new parameters
    const baseRevenue = 10000
    const adjustedGrowthRate = revenueGrowth / 100

    const revenue = []
    for (let i = 0; i < 12; i++) {
      const monthRevenue = baseRevenue * Math.pow(1 + adjustedGrowthRate, i)
      const churnAdjustment = 1 - churnRate / 100
      const finalRevenue = monthRevenue * churnAdjustment

      revenue.push({
        month: new Date(2024, i).toLocaleString("default", { month: "short" }),
        value: Math.round(finalRevenue),
      })
    }

    // Update costs based on new CAC
    const costs = [
      { category: "Marketing", value: cac * 50 },
      { category: "Development", value: 80000 },
      { category: "Operations", value: 25000 },
      { category: "Sales", value: 35000 },
      { category: "General", value: 15000 },
    ]

    const updatedModel = {
      projections: {
        revenue,
        costs,
        metrics: {
          arr: revenue[11].value * 12,
          mrr: revenue[11].value,
          cac,
          ltv: 1200,
          burnRate: 50000,
          runway: 18,
          grossMargin: 75,
        },
      },
    }

    return NextResponse.json(updatedModel)
  } catch (error) {
    console.error("Scenario planning error:", error)
    return NextResponse.json({ error: "Failed to update scenario" }, { status: 500 })
  }
}
