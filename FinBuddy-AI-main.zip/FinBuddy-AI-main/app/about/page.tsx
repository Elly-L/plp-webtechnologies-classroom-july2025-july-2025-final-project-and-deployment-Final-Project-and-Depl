"use client"

import { Header } from "@/components/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AIAssistant } from "@/components/ai-assistant"
import { Mail, Phone, MapPin, Award, Briefcase, Zap, Brain, Shield, TrendingUp } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function AboutPage() {
  const achievements = [
    { icon: Brain, title: "AI & Blockchain Expert", description: "Deep expertise in cutting-edge technologies" },
    { icon: Briefcase, title: "Serial Entrepreneur", description: "Founded multiple successful tech ventures" },
    { icon: Award, title: "Industry Recognition", description: "Featured speaker at major tech conferences" },
    { icon: TrendingUp, title: "Growth Specialist", description: "Helped 100+ startups scale their operations" },
  ]

  const experience = [
    {
      role: "Founder & CEO",
      company: "FinBuddy AI",
      period: "2024 - Present",
      description: "Building AI-powered financial modeling tools for startup founders",
    },
    {
      role: "Blockchain Consultant",
      company: "Various Startups",
      period: "2022 - 2024",
      description: "Advised on blockchain integration and cryptocurrency solutions",
    },
    {
      role: "AI Research Engineer",
      company: "Tech Innovation Lab",
      period: "2020 - 2022",
      description: "Developed machine learning models for financial prediction",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <div className="relative w-32 h-32 mx-auto mb-6">
              <Image
                src="/images/ceo-elly.jpg"
                alt="Elly Odhiambo - CEO & Founder"
                fill
                className="rounded-full object-cover border-4 border-primary/20"
              />
            </div>
            <h1 className="text-4xl font-bold mb-2">Elly Odhiambo</h1>
            <p className="text-xl text-muted-foreground mb-4">CEO & Founder, FinBuddy AI</p>
            <div className="flex justify-center gap-4 mb-6">
              <Badge variant="secondary" className="bg-primary/10 text-primary">
                <Brain className="mr-1 h-3 w-3" />
                AI Expert
              </Badge>
              <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-600">
                <Shield className="mr-1 h-3 w-3" />
                Blockchain Specialist
              </Badge>
              <Badge variant="secondary" className="bg-green-500/10 text-green-600">
                <Zap className="mr-1 h-3 w-3" />
                Tech Entrepreneur
              </Badge>
            </div>
            <div className="flex justify-center gap-4">
              <Button variant="outline" size="sm" asChild>
                <a href="mailto:ellylog.el@proton.me">
                  <Mail className="mr-2 h-4 w-4" />
                  Email
                </a>
              </Button>
              <Button variant="outline" size="sm" asChild>
                <a href="tel:+254719338534">
                  <Phone className="mr-2 h-4 w-4" />
                  Call
                </a>
              </Button>
              <Button variant="outline" size="sm" asChild>
                <a href="https://wa.me/254719338534" target="_blank" rel="noopener noreferrer">
                  <Phone className="mr-2 h-4 w-4" />
                  WhatsApp
                </a>
              </Button>
            </div>
          </div>

          {/* About Section */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-2xl">About Elly</CardTitle>
              <CardDescription>Visionary leader in AI and blockchain technology</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground leading-relaxed">
                Elly Odhiambo is a visionary technologist and serial entrepreneur with deep expertise in artificial
                intelligence and blockchain technology. As the founder and CEO of FinBuddy AI, he's on a mission to
                democratize financial modeling for startup founders worldwide.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                With over 8 years of experience in the tech industry, Elly has successfully founded and scaled multiple
                ventures, specializing in AI-driven solutions and blockchain implementations. His unique combination of
                technical expertise and business acumen has made him a sought-after advisor for startups and established
                companies alike.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Elly's passion for innovation and commitment to solving real-world problems through technology drives
                his work at FinBuddy AI, where he's building the next generation of financial modeling tools powered by
                artificial intelligence.
              </p>
            </CardContent>
          </Card>

          {/* Achievements */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6">Key Achievements</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {achievements.map((achievement, index) => (
                <Card key={index} className="hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                        <achievement.icon className="h-5 w-5 text-primary" />
                      </div>
                      <CardTitle className="text-lg">{achievement.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{achievement.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Experience */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6">Professional Experience</h2>
            <div className="space-y-6">
              {experience.map((exp, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{exp.role}</CardTitle>
                        <CardDescription className="text-primary font-medium">{exp.company}</CardDescription>
                      </div>
                      <Badge variant="outline">{exp.period}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{exp.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Vision & Mission */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
              <CardHeader>
                <CardTitle className="text-xl text-primary">Vision</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  To empower every startup founder with AI-driven financial modeling tools that make investor-ready
                  projections accessible, accurate, and actionable.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-yellow-500/5 to-yellow-500/10 border-yellow-500/20">
              <CardHeader>
                <CardTitle className="text-xl text-yellow-600">Mission</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  To bridge the gap between complex financial modeling and startup success by leveraging cutting-edge AI
                  technology to simplify the fundraising process.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Contact Information */}
          <Card className="bg-gradient-to-r from-primary/10 to-yellow-500/10 border-primary/20">
            <CardHeader>
              <CardTitle className="text-xl">Get in Touch</CardTitle>
              <CardDescription>Ready to discuss your startup's financial modeling needs?</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">Email</p>
                      <p className="text-sm text-muted-foreground">ellylog.el@proton.me</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">Phone</p>
                      <p className="text-sm text-muted-foreground">+254719338534</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">Location</p>
                      <p className="text-sm text-muted-foreground">Nairobi, Kenya</p>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  <Button asChild className="w-full">
                    <a href="mailto:ellylog.el@proton.me">
                      <Mail className="mr-2 h-4 w-4" />
                      Send Email
                    </a>
                  </Button>
                  <Button variant="outline" asChild className="w-full bg-transparent">
                    <a href="https://wa.me/254719338534" target="_blank" rel="noopener noreferrer">
                      <Phone className="mr-2 h-4 w-4" />
                      WhatsApp Chat
                    </a>
                  </Button>
                  <Button variant="outline" asChild className="w-full bg-transparent">
                    <Link href="/model-builder">
                      <Zap className="mr-2 h-4 w-4" />
                      Try FinBuddy AI
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <AIAssistant
        context="about Elly Odhiambo and FinBuddy AI"
        placeholder="Ask me about Elly's background, experience, or FinBuddy AI..."
      />
    </div>
  )
}
