import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AIAssistant } from "@/components/ai-assistant"
import {
  ArrowRight,
  BarChart3,
  Brain,
  Clock,
  DollarSign,
  FileText,
  Shield,
  Star,
  TrendingUp,
  Users,
  Zap,
  Mail,
  Phone,
  MessageSquare,
} from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  const features = [
    {
      icon: Brain,
      title: "AI-Powered Modeling",
      description: "Advanced AI helps you create accurate financial projections with minimal input",
    },
    {
      icon: Clock,
      title: "2-4 Hour Setup",
      description: "Go from zero to investor-ready projections in just a few hours",
    },
    {
      icon: BarChart3,
      title: "Interactive Dashboard",
      description: "Visualize your data with beautiful charts and scenario planning tools",
    },
    {
      icon: FileText,
      title: "Export Ready",
      description: "Generate professional PDFs and Excel files for investors",
    },
    {
      icon: Shield,
      title: "Blockchain Verified",
      description: "Optional blockchain verification for model authenticity",
    },
    {
      icon: Users,
      title: "Shareable Links",
      description: "Create secure, read-only links to share with stakeholders",
    },
  ]

  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Founder, TechStart",
      content:
        "FinBuddy AI helped me create professional financial projections that impressed investors. Raised $2M in Series A!",
      rating: 5,
    },
    {
      name: "Marcus Rodriguez",
      role: "CEO, GreenTech Solutions",
      content: "As a non-finance founder, this tool was a game-changer. The AI guidance made complex modeling simple.",
      rating: 5,
    },
    {
      name: "Emily Watson",
      role: "Startup Advisor",
      content:
        "I recommend FinBuddy AI to all my portfolio companies. The quality of projections is consistently high.",
      rating: 5,
    },
  ]

  const steps = [
    {
      number: "01",
      title: "Answer Smart Questions",
      description: "Our AI asks the right questions about your startup, market, and business model",
    },
    {
      number: "02",
      title: "Review & Refine",
      description: "Explore interactive dashboards and adjust scenarios with real-time feedback",
    },
    {
      number: "03",
      title: "Export & Share",
      description: "Generate professional reports and share secure links with investors",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-yellow-500/10" />
        <div className="container relative">
          <div className="mx-auto max-w-4xl text-center">
            <Badge variant="secondary" className="mb-4">
              <Zap className="mr-1 h-3 w-3" />
              AI-Powered Financial Modeling
            </Badge>
            <h1 className="text-4xl font-bold tracking-tight sm:text-6xl lg:text-7xl">
              From spreadsheet{" "}
              <span className="bg-gradient-to-r from-primary to-yellow-500 bg-clip-text text-transparent">stress</span>{" "}
              to pitch-perfect{" "}
              <span className="bg-gradient-to-r from-yellow-500 to-primary bg-clip-text text-transparent">clarity</span>
            </h1>
            <p className="mt-6 text-lg leading-8 text-muted-foreground max-w-2xl mx-auto">
              Create investor-ready financial projections in under 2–4 hours with AI assistance. No finance background
              required.
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-6">
              <Button
                asChild
                size="lg"
                className="bg-gradient-to-r from-primary to-yellow-500 hover:shadow-lg transition-all duration-300"
              >
                <Link href="/model-builder">
                  Start My Financial Model
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="#demo">Watch Demo</Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 left-10 animate-float">
          <div className="glass-effect rounded-full p-4">
            <DollarSign className="h-8 w-8 text-primary" />
          </div>
        </div>
        <div className="absolute top-40 right-10 animate-float" style={{ animationDelay: "2s" }}>
          <div className="glass-effect rounded-full p-4">
            <TrendingUp className="h-8 w-8 text-yellow-500" />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/50">
        <div className="container">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              Everything you need for financial modeling
            </h2>
            <p className="mt-4 text-lg text-muted-foreground">
              Powerful features designed specifically for startup founders
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20">
        <div className="container">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Simple 3-step process</h2>
            <p className="mt-4 text-lg text-muted-foreground">
              Get from idea to investor-ready projections in hours, not weeks
            </p>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <div className="flex flex-col items-center text-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r from-primary to-yellow-500 text-white text-xl font-bold mb-6">
                    {step.number}
                  </div>
                  <h3 className="text-xl font-semibold mb-4">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-full w-full">
                    <ArrowRight className="h-6 w-6 text-muted-foreground mx-auto" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-muted/50">
        <div className="container">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Trusted by founders worldwide</h2>
            <p className="mt-4 text-lg text-muted-foreground">
              See what successful entrepreneurs say about FinBuddy AI
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4">"{testimonial.content}"</p>
                  <div>
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-6">
              Ready to create your financial model?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Join thousands of founders who've successfully raised funding with FinBuddy AI
            </p>
            <Button
              asChild
              size="lg"
              className="bg-gradient-to-r from-primary to-yellow-500 hover:shadow-lg transition-all duration-300"
            >
              <Link href="/model-builder">
                Start Building Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                  <Zap className="h-5 w-5 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold">FinBuddy AI</span>
              </div>
              <p className="text-muted-foreground mb-4">AI-powered financial modeling for startup founders</p>
              <div className="flex space-x-3">
                <Button variant="outline" size="sm" asChild>
                  <a href="mailto:ellylog.el@proton.me">
                    <Mail className="h-4 w-4" />
                  </a>
                </Button>
                <Button variant="outline" size="sm" asChild>
                  <a href="tel:+254719338534">
                    <Phone className="h-4 w-4" />
                  </a>
                </Button>
                <Button variant="outline" size="sm" asChild>
                  <a href="https://wa.me/254719338534" target="_blank" rel="noopener noreferrer">
                    <MessageSquare className="h-4 w-4" />
                  </a>
                </Button>
              </div>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="/model-builder" className="hover:text-foreground">
                    Model Builder
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard" className="hover:text-foreground">
                    Dashboard
                  </Link>
                </li>
                <li>
                  <Link href="/share-tools" className="hover:text-foreground">
                    Share Tools
                  </Link>
                </li>
                <li>
                  <Link href="/pricing" className="hover:text-foreground">
                    Pricing
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Resources</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="/docs" className="hover:text-foreground">
                    Documentation
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="hover:text-foreground">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="/support" className="hover:text-foreground">
                    Support
                  </Link>
                </li>
                <li>
                  <Link href="/tutorials" className="hover:text-foreground">
                    Tutorials
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="/about" className="hover:text-foreground">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-foreground">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-foreground">
                    Privacy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-foreground">
                    Terms
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-8 pt-8 text-center text-muted-foreground">
            <p>
              &copy; 2024 FinBuddy AI. All rights reserved. Built by{" "}
              <Link href="/about" className="text-primary hover:underline">
                Elly Odhiambo
              </Link>
            </p>
          </div>
        </div>
      </footer>

      <AIAssistant context="homepage" placeholder="Ask me about FinBuddy AI features..." />
    </div>
  )
}
