"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  CompanyNameModal,
  IndustrySectorModal,
  BusinessModelModal,
  CompanyDescriptionModal,
  TAMModal,
  SAMModal,
  SOMModal,
  RevenueModelModal,
  UnitEconomicsModal,
  FinancialProjectionsModal,
} from "@/components/individual-question-modals"
import { useToast } from "@/hooks/use-toast"
import { Building2, Zap, Play, Target, DollarSign, Calculator, TrendingUp } from "lucide-react"
import { useRouter } from "next/navigation"

interface FormData {
  companyName: string
  sector: string[]
  businessModel: string
  description: string
  tam: number
  tamUnit: "billions" | "millions"
  sam: number
  samUnit: "billions" | "millions"
  som: number
  somUnit: "billions" | "millions"
  marketDescription: string
  revenueModel: string[]
  pricing: number
  unitEconomics: string
  cac: number
  ltv: number
  grossMargin: number
  burnRate: number
  fundingNeeded: number
  runway: number
  useOfFunds: string
  teamSize: number
  foundingDate: string
  stage: string
  previousFunding: number
  competitors: string
  competitiveAdvantage: string
  customerSegments: string
  marketingChannels: string[]
  operationalCosts: number
  technologyStack: string
  intellectualProperty: string
  partnerships: string
  riskFactors: string
  mitigationStrategies: string
}

const initialFormData: FormData = {
  companyName: "",
  sector: [],
  businessModel: "",
  description: "",
  tam: 0,
  tamUnit: "billions",
  sam: 0,
  samUnit: "billions",
  som: 0,
  somUnit: "millions",
  marketDescription: "",
  revenueModel: [],
  pricing: 0,
  unitEconomics: "",
  cac: 0,
  ltv: 0,
  grossMargin: 0,
  burnRate: 0,
  fundingNeeded: 0,
  runway: 0,
  useOfFunds: "",
  teamSize: 0,
  foundingDate: "",
  stage: "",
  previousFunding: 0,
  competitors: "",
  competitiveAdvantage: "",
  customerSegments: "",
  marketingChannels: [],
  operationalCosts: 0,
  technologyStack: "",
  intellectualProperty: "",
  partnerships: "",
  riskFactors: "",
  mitigationStrategies: "",
}

export default function ModelBuilderPage() {
  const [currentStep, setCurrentStep] = useState(-1)
  const [formData, setFormData] = useState<FormData>(initialFormData)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const questions = [
    { title: "Company Name", component: CompanyNameModal, icon: Building2 },
    { title: "Industry Sector", component: IndustrySectorModal, icon: Building2 },
    { title: "Business Model", component: BusinessModelModal, icon: Building2 },
    { title: "Company Description", component: CompanyDescriptionModal, icon: Building2 },
    { title: "Total Addressable Market", component: TAMModal, icon: Target },
    { title: "Serviceable Addressable Market", component: SAMModal, icon: Target },
    { title: "Serviceable Obtainable Market", component: SOMModal, icon: Target },
    { title: "Revenue Model", component: RevenueModelModal, icon: DollarSign },
    { title: "Unit Economics", component: UnitEconomicsModal, icon: Calculator },
    { title: "Financial Projections", component: FinancialProjectionsModal, icon: TrendingUp },
  ]

  const updateFormData = (field: keyof FormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const nextStep = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      generateModel()
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const closeModal = () => {
    setCurrentStep(-1)
  }

  const startQuestionnaire = () => {
    setCurrentStep(0)
  }

  const generateModel = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/financial-model", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      if (!response.ok) throw new Error("Failed to generate model")

      const result = await response.json()
      localStorage.setItem("financialModel", JSON.stringify(result))

      toast({
        title: "Success!",
        description: "Your financial model has been generated successfully.",
      })

      router.push("/dashboard")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate financial model. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-yellow-500 bg-clip-text text-transparent">
              AI-Powered Financial Model Builder
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Answer {questions.length} smart questions and let AI create investor-ready projections in minutes
            </p>
          </div>

          {currentStep === -1 ? (
            <div className="space-y-8">
              <Card className="text-center p-8">
                <CardHeader>
                  <CardTitle className="text-2xl mb-4">Ready to build your financial model?</CardTitle>
                  <CardDescription className="text-lg">
                    Our AI will guide you through {questions.length} comprehensive questions to create professional
                    projections
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    onClick={startQuestionnaire}
                    size="lg"
                    className="bg-gradient-to-r from-primary to-yellow-500 hover:shadow-lg transition-all duration-300"
                  >
                    <Play className="mr-2 h-5 w-5" />
                    Start Smart Questionnaire
                  </Button>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {questions.map((question, index) => (
                  <Card key={index} className="hover:shadow-lg transition-all duration-300">
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                          <question.icon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{question.title}</CardTitle>
                          <Badge variant="outline" className="mt-1">
                            Question {index + 1}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            </div>
          ) : isLoading ? (
            <div className="text-center">
              <div className="animate-pulse">
                <Zap className="h-12 w-12 mx-auto mb-4 text-primary" />
                <p className="text-lg">Building your financial model...</p>
              </div>
            </div>
          ) : null}
        </div>
      </div>

      {/* All Question Modals */}
      <CompanyNameModal
        isOpen={currentStep === 0}
        onClose={closeModal}
        onNext={nextStep}
        onPrev={prevStep}
        formData={formData}
        updateFormData={updateFormData}
        currentStep={currentStep}
        totalSteps={questions.length}
      />

      <IndustrySectorModal
        isOpen={currentStep === 1}
        onClose={closeModal}
        onNext={nextStep}
        onPrev={prevStep}
        formData={formData}
        updateFormData={updateFormData}
        currentStep={currentStep}
        totalSteps={questions.length}
      />

      <BusinessModelModal
        isOpen={currentStep === 2}
        onClose={closeModal}
        onNext={nextStep}
        onPrev={prevStep}
        formData={formData}
        updateFormData={updateFormData}
        currentStep={currentStep}
        totalSteps={questions.length}
      />

      <CompanyDescriptionModal
        isOpen={currentStep === 3}
        onClose={closeModal}
        onNext={nextStep}
        onPrev={prevStep}
        formData={formData}
        updateFormData={updateFormData}
        currentStep={currentStep}
        totalSteps={questions.length}
      />

      <TAMModal
        isOpen={currentStep === 4}
        onClose={closeModal}
        onNext={nextStep}
        onPrev={prevStep}
        formData={formData}
        updateFormData={updateFormData}
        currentStep={currentStep}
        totalSteps={questions.length}
      />

      <SAMModal
        isOpen={currentStep === 5}
        onClose={closeModal}
        onNext={nextStep}
        onPrev={prevStep}
        formData={formData}
        updateFormData={updateFormData}
        currentStep={currentStep}
        totalSteps={questions.length}
      />

      <SOMModal
        isOpen={currentStep === 6}
        onClose={closeModal}
        onNext={nextStep}
        onPrev={prevStep}
        formData={formData}
        updateFormData={updateFormData}
        currentStep={currentStep}
        totalSteps={questions.length}
      />

      <RevenueModelModal
        isOpen={currentStep === 7}
        onClose={closeModal}
        onNext={nextStep}
        onPrev={prevStep}
        formData={formData}
        updateFormData={updateFormData}
        currentStep={currentStep}
        totalSteps={questions.length}
      />

      <UnitEconomicsModal
        isOpen={currentStep === 8}
        onClose={closeModal}
        onNext={nextStep}
        onPrev={prevStep}
        formData={formData}
        updateFormData={updateFormData}
        currentStep={currentStep}
        totalSteps={questions.length}
      />

      <FinancialProjectionsModal
        isOpen={currentStep === 9}
        onClose={closeModal}
        onNext={nextStep}
        onPrev={prevStep}
        formData={formData}
        updateFormData={updateFormData}
        currentStep={currentStep}
        totalSteps={questions.length}
      />
    </div>
  )
}
