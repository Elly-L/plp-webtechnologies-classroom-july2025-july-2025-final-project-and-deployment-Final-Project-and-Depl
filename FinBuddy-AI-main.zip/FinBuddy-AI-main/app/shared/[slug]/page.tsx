"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import { DollarSign, TrendingUp, Users, Calendar, Shield, Zap, ExternalLink, Mail } from "lucide-react"
import { useParams } from "next/navigation"

interface SharedModel {
  id: string
  companyName: string
  description: string
  createdAt: string
  author: {
    name: string
    email: string
    company: string
  }
  projections: {
    revenue: Array<{ month: string; value: number }>
    costs: Array<{ category: string; value: number }>
    metrics: {
      arr: number
      mrr: number
      cac: number
      ltv: number
      burnRate: number
      runway: number
      grossMargin: number
    }
  }
  settings: {
    allowComments: boolean
    showContactInfo: boolean
  }
  isVerified: boolean
}

export default function SharedModelPage() {
  const params = useParams()
  const [model, setModel] = useState<SharedModel | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchSharedModel = async () => {
      try {
        const response = await fetch(`/api/shared/${params.slug}`)

        if (!response.ok) {
          throw new Error("Model not found or access denied")
        }

        const data = await response.json()
        setModel(data)
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load model")
      } finally {
        setIsLoading(false)
      }
    }

    if (params.slug) {
      fetchSharedModel()
    }
  }, [params.slug])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Zap className="h-12 w-12 animate-spin mx-auto mb-4 text-primary" />
          <p className="text-lg">Loading financial model...</p>
        </div>
      </div>
    )
  }

  if (error || !model) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="h-12 w-12 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="h-6 w-6 text-destructive" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
          <p className="text-muted-foreground mb-4">
            {error || "This financial model is not available or has been removed."}
          </p>
          <Button asChild>
            <a href="/">Return to FinBuddy AI</a>
          </Button>
        </div>
      </div>
    )
  }

  const COLORS = ["#0A84FF", "#FFD60A", "#34C759", "#FF3B30", "#AF52DE"]

  const MetricCard = ({ title, value, icon: Icon, format = "currency" }: any) => (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold">
              {format === "currency"
                ? `$${value.toLocaleString()}`
                : format === "percentage"
                  ? `${value}%`
                  : format === "months"
                    ? `${value} months`
                    : value.toLocaleString()}
            </p>
          </div>
          <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon className="h-6 w-6 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <Zap className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-primary to-yellow-500 bg-clip-text text-transparent">
              FinBuddy AI
            </span>
          </div>
          <div className="flex items-center space-x-2">
            {model.isVerified && (
              <Badge variant="outline" className="border-green-500 text-green-600">
                <Shield className="mr-1 h-3 w-3" />
                Blockchain Verified
              </Badge>
            )}
            <Badge variant="secondary">Read-Only</Badge>
          </div>
        </div>
      </header>

      <div className="container py-8">
        {/* Company Header */}
        <div className="mb-8">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">{model.companyName}</h1>
              <p className="text-muted-foreground mb-4 max-w-2xl">{model.description}</p>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>Created {new Date(model.createdAt).toLocaleDateString()}</span>
                <span>•</span>
                <span>By {model.author.name}</span>
                {model.author.company && (
                  <>
                    <span>•</span>
                    <span>{model.author.company}</span>
                  </>
                )}
              </div>
            </div>
            {model.settings.showContactInfo && (
              <Card className="w-64">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="h-4 w-4" />
                    <a href={`mailto:${model.author.email}`} className="hover:underline">
                      {model.author.email}
                    </a>
                  </div>
                  <Button size="sm" className="w-full" asChild>
                    <a href={`mailto:${model.author.email}?subject=Regarding ${model.companyName} Financial Model`}>
                      <Mail className="mr-2 h-4 w-4" />
                      Contact Founder
                    </a>
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard title="Annual Recurring Revenue" value={model.projections.metrics.arr} icon={DollarSign} />
          <MetricCard title="Monthly Recurring Revenue" value={model.projections.metrics.mrr} icon={TrendingUp} />
          <MetricCard title="Customer Acquisition Cost" value={model.projections.metrics.cac} icon={Users} />
          <MetricCard title="Runway" value={model.projections.metrics.runway} icon={Calendar} format="months" />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Revenue Forecast */}
          <Card>
            <CardHeader>
              <CardTitle>Revenue Forecast</CardTitle>
              <CardDescription>Monthly revenue projections for the next 12 months</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="chart-container">
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={model.projections.revenue}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, "Revenue"]} />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#0A84FF"
                      strokeWidth={3}
                      dot={{ fill: "#0A84FF", strokeWidth: 2, r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Cost Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Cost Breakdown</CardTitle>
              <CardDescription>Monthly operating expenses by category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="chart-container">
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={model.projections.costs}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ category, percent }) => `${category} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {model.projections.costs.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, "Cost"]} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Key Ratios */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Key Financial Ratios</CardTitle>
            <CardDescription>Important financial health indicators</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <p className="text-2xl font-bold">
                  {(model.projections.metrics.ltv / model.projections.metrics.cac).toFixed(1)}:1
                </p>
                <p className="text-sm text-muted-foreground">LTV:CAC Ratio</p>
                <Badge
                  variant={
                    model.projections.metrics.ltv / model.projections.metrics.cac >= 3 ? "default" : "destructive"
                  }
                  className="mt-1"
                >
                  {model.projections.metrics.ltv / model.projections.metrics.cac >= 3 ? "Healthy" : "Needs Improvement"}
                </Badge>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">{model.projections.metrics.grossMargin}%</p>
                <p className="text-sm text-muted-foreground">Gross Margin</p>
                <Badge variant="outline" className="mt-1">
                  Excellent
                </Badge>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">${model.projections.metrics.burnRate.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Monthly Burn</p>
                <Badge variant="outline" className="mt-1">
                  Sustainable
                </Badge>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">Month 14</p>
                <p className="text-sm text-muted-foreground">Break-even Point</p>
                <Badge variant="outline" className="mt-1">
                  On Track
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="border-t pt-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="flex h-6 w-6 items-center justify-center rounded bg-primary">
                  <Zap className="h-4 w-4 text-primary-foreground" />
                </div>
                <span className="text-sm font-medium">Generated by FinBuddy AI</span>
              </div>
              {model.isVerified && (
                <Badge variant="outline" className="border-green-500 text-green-600">
                  <Shield className="mr-1 h-3 w-3" />
                  Blockchain Verified
                </Badge>
              )}
            </div>
            <Button variant="outline" asChild>
              <a href="/" target="_blank" rel="noopener noreferrer">
                <ExternalLink className="mr-2 h-4 w-4" />
                Create Your Own Model
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
