"use client"

import { Header } from "@/components/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { AIAssistant } from "@/components/ai-assistant"
import { BookOpen, Calculator, Target, DollarSign, BarChart3, Lightbulb, HelpCircle } from "lucide-react"

export default function DocsPage() {
  const sections = [
    {
      title: "Getting Started",
      icon: BookOpen,
      items: [
        { title: "Quick Start Guide", description: "Get up and running in 5 minutes" },
        { title: "Understanding Financial Models", description: "Learn the basics of startup finance" },
        { title: "AI Assistant Features", description: "How to use AI to enhance your model" },
      ],
    },
    {
      title: "Financial Metrics",
      icon: Calculator,
      items: [
        { title: "Key Performance Indicators", description: "ARR, MRR, CAC, LTV and more" },
        { title: "Unit Economics", description: "Understanding customer profitability" },
        { title: "Burn Rate & Runway", description: "Managing cash flow effectively" },
      ],
    },
    {
      title: "Market Analysis",
      icon: Target,
      items: [
        { title: "TAM, SAM, SOM", description: "Market sizing methodology" },
        { title: "Competitive Analysis", description: "Positioning against competitors" },
        { title: "Market Research", description: "Finding reliable data sources" },
      ],
    },
    {
      title: "Revenue Models",
      icon: DollarSign,
      items: [
        { title: "SaaS Models", description: "Subscription-based revenue" },
        { title: "Marketplace Models", description: "Commission and transaction fees" },
        { title: "Freemium Strategy", description: "Converting free users to paid" },
      ],
    },
  ]

  const faqs = [
    {
      question: "How accurate are the AI-generated projections?",
      answer:
        "Our AI uses industry benchmarks and best practices to create realistic projections. However, all models should be validated with your specific market data and assumptions.",
    },
    {
      question: "Can I export my financial model?",
      answer:
        "Yes! You can export your model as PDF, Excel, or Word documents. Each format is optimized for different use cases - PDF for presentations, Excel for analysis, and Word for detailed reports.",
    },
    {
      question: "How do I share my model with investors?",
      answer:
        "Use our secure sharing feature to create read-only links. You can set passwords, expiration dates, and control what information is visible to viewers.",
    },
    {
      question: "What if I need help with specific financial terms?",
      answer:
        "Our AI assistant is available throughout the platform to explain financial concepts, help with calculations, and provide industry insights.",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">Documentation</h1>
            <p className="text-xl text-muted-foreground">
              Everything you need to know about building financial models with FinBuddy AI
            </p>
          </div>

          {/* Quick Links */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <Card className="text-center hover:shadow-lg transition-all duration-300">
              <CardHeader>
                <Lightbulb className="h-8 w-8 mx-auto text-primary mb-2" />
                <CardTitle className="text-lg">Quick Start</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Get started in minutes</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-all duration-300">
              <CardHeader>
                <Calculator className="h-8 w-8 mx-auto text-primary mb-2" />
                <CardTitle className="text-lg">Metrics Guide</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Understand key metrics</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-all duration-300">
              <CardHeader>
                <BarChart3 className="h-8 w-8 mx-auto text-primary mb-2" />
                <CardTitle className="text-lg">Best Practices</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Industry standards</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-all duration-300">
              <CardHeader>
                <HelpCircle className="h-8 w-8 mx-auto text-primary mb-2" />
                <CardTitle className="text-lg">FAQ</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Common questions</p>
              </CardContent>
            </Card>
          </div>

          {/* Documentation Sections */}
          <div className="space-y-12">
            {sections.map((section, index) => (
              <div key={index}>
                <div className="flex items-center gap-3 mb-6">
                  <section.icon className="h-6 w-6 text-primary" />
                  <h2 className="text-2xl font-bold">{section.title}</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {section.items.map((item, itemIndex) => (
                    <Card key={itemIndex} className="hover:shadow-lg transition-all duration-300">
                      <CardHeader>
                        <CardTitle className="text-lg">{item.title}</CardTitle>
                        <CardDescription>{item.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Badge variant="outline">Coming Soon</Badge>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <Separator className="my-12" />

          {/* FAQ Section */}
          <div>
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <HelpCircle className="h-6 w-6 text-primary" />
              Frequently Asked Questions
            </h2>
            <div className="space-y-6">
              {faqs.map((faq, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="text-lg">{faq.question}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{faq.answer}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Contact Support */}
          <Card className="mt-12 bg-gradient-to-r from-primary/10 to-yellow-500/10 border-primary/20">
            <CardHeader>
              <CardTitle className="text-xl">Need More Help?</CardTitle>
              <CardDescription>Our team is here to help you succeed with your financial modeling</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <p className="text-sm text-muted-foreground mb-2">
                    <strong>Email:</strong> ellylog.el@proton.me
                  </p>
                  <p className="text-sm text-muted-foreground">
                    <strong>Phone:</strong> +254719338534
                  </p>
                </div>
                <div className="flex gap-2">
                  <Badge variant="secondary">Response within 24h</Badge>
                  <Badge variant="secondary">Expert Support</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <AIAssistant
        context="documentation and help"
        placeholder="Ask me about financial modeling, metrics, or how to use FinBuddy AI..."
      />
    </div>
  )
}
