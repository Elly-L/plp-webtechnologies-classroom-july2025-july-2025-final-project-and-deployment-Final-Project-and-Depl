"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  ArrowLeft,
  ArrowRight,
  Building2,
  Sparkles,
  Undo2,
  Target,
  DollarSign,
  TrendingUp,
  Calculator,
  Info,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface FormData {
  companyName: string
  sector: string[]
  businessModel: string
  description: string
  tam: number
  tamUnit: "billions" | "millions"
  sam: number
  samUnit: "billions" | "millions"
  som: number
  somUnit: "billions" | "millions"
  marketDescription: string
  revenueModel: string[]
  pricing: number
  unitEconomics: string
  cac: number
  ltv: number
  grossMargin: number
  burnRate: number
  fundingNeeded: number
  runway: number
  useOfFunds: string
  teamSize: number
  foundingDate: string
  stage: string
  previousFunding: number
  competitors: string
  competitiveAdvantage: string
  customerSegments: string
  marketingChannels: string[]
  operationalCosts: number
  technologyStack: string
  intellectualProperty: string
  partnerships: string
  riskFactors: string
  mitigationStrategies: string
}

interface QuestionModalProps {
  isOpen: boolean
  onClose: () => void
  onNext: () => void
  onPrev: () => void
  formData: FormData
  updateFormData: (field: keyof FormData, value: any) => void
  currentStep: number
  totalSteps: number
}

const industries = [
  "FinTech",
  "HealthTech",
  "EdTech",
  "E-commerce",
  "SaaS",
  "Marketplace",
  "AI/ML",
  "Blockchain",
  "IoT",
  "Cybersecurity",
  "Gaming",
  "Social Media",
  "Food & Beverage",
  "Transportation",
  "Real Estate",
  "Energy",
  "Agriculture",
  "Other",
]

const revenueModels = [
  "Subscription (SaaS)",
  "Transaction Fees",
  "Marketplace Commission",
  "Advertising",
  "Freemium",
  "One-time Purchase",
  "Licensing",
  "Affiliate Marketing",
]

const marketingChannels = [
  "Digital Marketing",
  "Content Marketing",
  "Social Media",
  "SEO/SEM",
  "Email Marketing",
  "Influencer Marketing",
  "PR/Media",
  "Events/Conferences",
  "Partnerships",
  "Referral Programs",
  "Direct Sales",
  "Cold Outreach",
]

const stages = ["Pre-Seed", "Seed", "Series A", "Series B", "Series C+", "Growth", "IPO Ready"]

// AI Assistant Modal for Unit Economics
const UnitEconomicsAIModal = ({
  isOpen,
  onClose,
  onCalculate,
}: {
  isOpen: boolean
  onClose: () => void
  onCalculate: (data: { cac: number; ltv: number; grossMargin: number }) => void
}) => {
  const [responses, setResponses] = useState({
    monthlyRevenue: "",
    customerLifespan: "",
    acquisitionCost: "",
    grossMarginPercent: "",
    churnRate: "",
  })
  const [isCalculating, setIsCalculating] = useState(false)
  const { toast } = useToast()

  const handleCalculate = async () => {
    setIsCalculating(true)
    try {
      const response = await fetch("/api/ai-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: `Calculate unit economics based on: Monthly revenue per customer: $${responses.monthlyRevenue}, Customer lifespan: ${responses.customerLifespan} months, Customer acquisition cost: $${responses.acquisitionCost}, Gross margin: ${responses.grossMarginPercent}%, Monthly churn rate: ${responses.churnRate}%. Return only the calculated values for CAC, LTV, and Gross Margin as numbers.`,
          context: "unit economics calculation",
          history: [],
        }),
      })

      if (response.ok) {
        const data = await response.json()
        // Extract numbers from AI response
        const cacMatch = data.response.match(/CAC[:\s]*\$?(\d+(?:\.\d+)?)/i)
        const ltvMatch = data.response.match(/LTV[:\s]*\$?(\d+(?:\.\d+)?)/i)
        const marginMatch = data.response.match(/(?:Gross\s*)?Margin[:\s]*(\d+(?:\.\d+)?)%?/i)

        const calculatedData = {
          cac: cacMatch ? Number.parseFloat(cacMatch[1]) : Number.parseFloat(responses.acquisitionCost) || 0,
          ltv: ltvMatch
            ? Number.parseFloat(ltvMatch[1])
            : Number.parseFloat(responses.monthlyRevenue) * Number.parseFloat(responses.customerLifespan) || 0,
          grossMargin: marginMatch
            ? Number.parseFloat(marginMatch[1])
            : Number.parseFloat(responses.grossMarginPercent) || 0,
        }

        onCalculate(calculatedData)
        onClose()
        toast({
          title: "Unit Economics Calculated",
          description: "Your metrics have been calculated and filled in.",
        })
      }
    } catch (error) {
      toast({
        title: "Calculation Failed",
        description: "Please try again or enter values manually.",
        variant: "destructive",
      })
    } finally {
      setIsCalculating(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            AI Unit Economics Calculator
          </DialogTitle>
          <DialogDescription>Answer these questions to calculate your unit economics</DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 pr-4 max-h-[60vh]">
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="monthlyRevenue">Average monthly revenue per customer ($)</Label>
              <Input
                id="monthlyRevenue"
                value={responses.monthlyRevenue}
                onChange={(e) => setResponses((prev) => ({ ...prev, monthlyRevenue: e.target.value }))}
                placeholder="e.g., 50"
                type="number"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="customerLifespan">Average customer lifespan (months)</Label>
              <Input
                id="customerLifespan"
                value={responses.customerLifespan}
                onChange={(e) => setResponses((prev) => ({ ...prev, customerLifespan: e.target.value }))}
                placeholder="e.g., 24"
                type="number"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="acquisitionCost">Cost to acquire one customer ($)</Label>
              <Input
                id="acquisitionCost"
                value={responses.acquisitionCost}
                onChange={(e) => setResponses((prev) => ({ ...prev, acquisitionCost: e.target.value }))}
                placeholder="e.g., 150"
                type="number"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="grossMarginPercent">Gross margin percentage (%)</Label>
              <Input
                id="grossMarginPercent"
                value={responses.grossMarginPercent}
                onChange={(e) => setResponses((prev) => ({ ...prev, grossMarginPercent: e.target.value }))}
                placeholder="e.g., 75"
                type="number"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="churnRate">Monthly churn rate (%)</Label>
              <Input
                id="churnRate"
                value={responses.churnRate}
                onChange={(e) => setResponses((prev) => ({ ...prev, churnRate: e.target.value }))}
                placeholder="e.g., 5"
                type="number"
              />
            </div>
          </div>
        </ScrollArea>

        <div className="flex-shrink-0 space-y-4 pt-4 border-t">
          <div className="flex justify-between">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              onClick={handleCalculate}
              disabled={isCalculating || !responses.monthlyRevenue || !responses.customerLifespan}
            >
              {isCalculating ? (
                <>
                  <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                  Calculating...
                </>
              ) : (
                <>
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// Financial Terms Explanation Modal
const FinancialTermsModal = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => (
  <Dialog open={isOpen} onOpenChange={onClose}>
    <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
      <DialogHeader className="flex-shrink-0">
        <DialogTitle className="flex items-center gap-2">
          <Info className="h-5 w-5" />
          Financial Terms Explained
        </DialogTitle>
        <DialogDescription>Understanding key financial metrics for startups</DialogDescription>
      </DialogHeader>

      <ScrollArea className="flex-1 pr-4">
        <div className="space-y-6 py-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Monthly Burn Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                The amount of money your company spends each month to operate. This includes salaries, rent, marketing
                costs, and other operational expenses. A lower burn rate means your money lasts longer.
              </p>
              <p className="text-sm mt-2">
                <strong>Example:</strong> If you spend $50,000 per month, your burn rate is $50,000.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Runway</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                How many months your company can operate with current cash before running out of money. Calculated as:
                Current Cash ÷ Monthly Burn Rate.
              </p>
              <p className="text-sm mt-2">
                <strong>Example:</strong> $500,000 cash ÷ $50,000 burn rate = 10 months runway.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Customer Acquisition Cost (CAC)</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                The total cost to acquire one new customer, including marketing, sales, and advertising expenses.
              </p>
              <p className="text-sm mt-2">
                <strong>Formula:</strong> Total Marketing & Sales Costs ÷ Number of New Customers
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Customer Lifetime Value (LTV)</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                The total revenue you expect from a customer over their entire relationship with your company.
              </p>
              <p className="text-sm mt-2">
                <strong>Formula:</strong> Average Monthly Revenue × Customer Lifespan (months)
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Gross Margin</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                The percentage of revenue left after subtracting the direct costs of producing your product or service.
              </p>
              <p className="text-sm mt-2">
                <strong>Formula:</strong> (Revenue - Cost of Goods Sold) ÷ Revenue × 100
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Funding Needed</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                The amount of investment required to reach your next milestone (usually profitability or next funding
                round).
              </p>
              <p className="text-sm mt-2">
                <strong>Calculation:</strong> Monthly Burn Rate × Months to Milestone + Buffer
              </p>
            </CardContent>
          </Card>
        </div>
      </ScrollArea>

      <div className="flex-shrink-0 pt-4 border-t">
        <Button onClick={onClose} className="w-full">
          Got it!
        </Button>
      </div>
    </DialogContent>
  </Dialog>
)

// Question 1: Company Name
export const CompanyNameModal = ({
  isOpen,
  onClose,
  onNext,
  formData,
  updateFormData,
  currentStep,
  totalSteps,
}: QuestionModalProps) => (
  <Dialog open={isOpen} onOpenChange={onClose}>
    <DialogContent className="max-w-lg max-h-[90vh] flex flex-col">
      <DialogHeader className="flex-shrink-0">
        <DialogTitle className="flex items-center gap-2">
          <Building2 className="h-5 w-5" />
          Company Name
        </DialogTitle>
        <DialogDescription>What's the name of your startup?</DialogDescription>
      </DialogHeader>

      <ScrollArea className="flex-1 pr-4 max-h-[60vh]">
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="companyName">Company Name *</Label>
            <Input
              id="companyName"
              value={formData.companyName}
              onChange={(e) => updateFormData("companyName", e.target.value)}
              placeholder="Enter your company name"
              className="text-lg"
            />
            <p className="text-sm text-muted-foreground">
              This will appear on all your financial reports and investor materials.
            </p>
          </div>
        </div>
      </ScrollArea>

      <div className="flex-shrink-0 space-y-4 pt-4 border-t">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Progress</span>
            <span>
              {currentStep + 1} of {totalSteps}
            </span>
          </div>
          <Progress value={((currentStep + 1) / totalSteps) * 100} className="h-2" />
        </div>
        <div className="flex justify-between">
          <Button variant="outline" disabled>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Previous
          </Button>
          <Button onClick={onNext} disabled={!formData.companyName.trim()}>
            Next
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </DialogContent>
  </Dialog>
)

// Question 2: Industry Sector
export const IndustrySectorModal = ({
  isOpen,
  onClose,
  onNext,
  onPrev,
  formData,
  updateFormData,
  currentStep,
  totalSteps,
}: QuestionModalProps) => (
  <Dialog open={isOpen} onOpenChange={onClose}>
    <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
      <DialogHeader className="flex-shrink-0">
        <DialogTitle className="flex items-center gap-2">
          <Building2 className="h-5 w-5" />
          Industry Sector
        </DialogTitle>
        <DialogDescription>Which industries does your startup operate in? (Select all that apply)</DialogDescription>
      </DialogHeader>

      <ScrollArea className="flex-1 pr-4 max-h-[60vh]">
        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {industries.map((industry) => (
              <div key={industry} className="flex items-center space-x-2 p-2 rounded-lg hover:bg-muted/50">
                <Checkbox
                  id={industry}
                  checked={formData.sector.includes(industry)}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      updateFormData("sector", [...formData.sector, industry])
                    } else {
                      updateFormData(
                        "sector",
                        formData.sector.filter((s) => s !== industry),
                      )
                    }
                  }}
                />
                <Label htmlFor={industry} className="text-sm cursor-pointer">
                  {industry}
                </Label>
              </div>
            ))}
          </div>
          {formData.sector.length > 0 && (
            <div className="mt-4">
              <p className="text-sm font-medium mb-2">Selected industries:</p>
              <div className="flex flex-wrap gap-2">
                {formData.sector.map((sector) => (
                  <Badge key={sector} variant="secondary">
                    {sector}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      <div className="flex-shrink-0 space-y-4 pt-4 border-t">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Progress</span>
            <span>
              {currentStep + 1} of {totalSteps}
            </span>
          </div>
          <Progress value={((currentStep + 1) / totalSteps) * 100} className="h-2" />
        </div>
        <div className="flex justify-between">
          <Button variant="outline" onClick={onPrev}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Previous
          </Button>
          <Button onClick={onNext} disabled={formData.sector.length === 0}>
            Next
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </DialogContent>
  </Dialog>
)

// Question 3: Business Model
export const BusinessModelModal = ({
  isOpen,
  onClose,
  onNext,
  onPrev,
  formData,
  updateFormData,
  currentStep,
  totalSteps,
}: QuestionModalProps) => (
  <Dialog open={isOpen} onOpenChange={onClose}>
    <DialogContent className="max-w-lg max-h-[90vh] flex flex-col">
      <DialogHeader className="flex-shrink-0">
        <DialogTitle className="flex items-center gap-2">
          <Building2 className="h-5 w-5" />
          Business Model
        </DialogTitle>
        <DialogDescription>Who are your primary customers?</DialogDescription>
      </DialogHeader>

      <ScrollArea className="flex-1 pr-4 max-h-[60vh]">
        <div className="space-y-4 py-4">
          <RadioGroup
            value={formData.businessModel}
            onValueChange={(value) => updateFormData("businessModel", value)}
            className="space-y-4"
          >
            <div className="flex items-start space-x-3 p-4 rounded-lg border hover:bg-muted/50">
              <RadioGroupItem value="b2b" id="b2b" className="mt-1" />
              <div className="space-y-1">
                <Label htmlFor="b2b" className="font-medium">
                  B2B (Business to Business)
                </Label>
                <p className="text-sm text-muted-foreground">You sell products or services to other businesses</p>
              </div>
            </div>
            <div className="flex items-start space-x-3 p-4 rounded-lg border hover:bg-muted/50">
              <RadioGroupItem value="b2c" id="b2c" className="mt-1" />
              <div className="space-y-1">
                <Label htmlFor="b2c" className="font-medium">
                  B2C (Business to Consumer)
                </Label>
                <p className="text-sm text-muted-foreground">You sell directly to individual consumers</p>
              </div>
            </div>
            <div className="flex items-start space-x-3 p-4 rounded-lg border hover:bg-muted/50">
              <RadioGroupItem value="b2b2c" id="b2b2c" className="mt-1" />
              <div className="space-y-1">
                <Label htmlFor="b2b2c" className="font-medium">
                  B2B2C (Business to Business to Consumer)
                </Label>
                <p className="text-sm text-muted-foreground">You sell to businesses who then serve consumers</p>
              </div>
            </div>
          </RadioGroup>
        </div>
      </ScrollArea>

      <div className="flex-shrink-0 space-y-4 pt-4 border-t">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Progress</span>
            <span>
              {currentStep + 1} of {totalSteps}
            </span>
          </div>
          <Progress value={((currentStep + 1) / totalSteps) * 100} className="h-2" />
        </div>
        <div className="flex justify-between">
          <Button variant="outline" onClick={onPrev}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Previous
          </Button>
          <Button onClick={onNext} disabled={!formData.businessModel}>
            Next
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </DialogContent>
  </Dialog>
)

// Question 4: Company Description with Clean AI Enhancement
export const CompanyDescriptionModal = ({
  isOpen,
  onClose,
  onNext,
  onPrev,
  formData,
  updateFormData,
  currentStep,
  totalSteps,
}: QuestionModalProps) => {
  const [isEnhancing, setIsEnhancing] = useState(false)
  const [originalDescription, setOriginalDescription] = useState("")
  const { toast } = useToast()

  const enhanceDescription = async () => {
    if (!formData.description.trim()) return

    setOriginalDescription(formData.description)
    setIsEnhancing(true)

    try {
      const response = await fetch("/api/ai-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: `Polish this company description to be investor-ready and return ONLY the improved version: "${formData.description}"`,
          context: "company description enhancement - return only polished text",
          history: [],
        }),
      })

      if (response.ok) {
        const data = await response.json()
        // Clean the response to remove any formatting or explanations
        const cleanedResponse = data.response
          .replace(/\*\*/g, "") // Remove markdown bold
          .replace(/Here's.*?:/gi, "") // Remove "Here's a polished version:"
          .replace(/### Key Improvements:.*$/s, "") // Remove everything after improvements
          .replace(/\n.*$/s, "") // Remove everything after first line break
          .trim()
          .replace(/^["']|["']$/g, "") // Remove quotes at start/end

        updateFormData("description", cleanedResponse)
        toast({
          title: "Description Enhanced",
          description: "Your company description has been improved by AI.",
        })
      }
    } catch (error) {
      toast({
        title: "Enhancement Failed",
        description: "Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsEnhancing(false)
    }
  }

  const revertDescription = () => {
    if (originalDescription) {
      updateFormData("description", originalDescription)
      setOriginalDescription("")
      toast({
        title: "Reverted",
        description: "Description restored to original version.",
      })
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Company Description
          </DialogTitle>
          <DialogDescription>Describe what your company does and the problem you solve</DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 pr-4 max-h-[60vh]">
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="description">Company Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => updateFormData("description", e.target.value)}
                placeholder="Describe what your company does, the problem you solve, and your solution..."
                rows={6}
                className="resize-none"
              />
              <div className="flex justify-between items-center">
                <p className="text-sm text-muted-foreground">
                  Aim for 2-3 sentences that clearly explain your value proposition
                </p>
                <div className="flex gap-2">
                  {originalDescription && (
                    <Button variant="outline" size="sm" onClick={revertDescription}>
                      <Undo2 className="mr-2 h-4 w-4" />
                      Revert
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={enhanceDescription}
                    disabled={!formData.description.trim() || isEnhancing}
                  >
                    {isEnhancing ? (
                      <>
                        <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                        Enhancing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="mr-2 h-4 w-4" />
                        AI Enhance
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </ScrollArea>

        <div className="flex-shrink-0 space-y-4 pt-4 border-t">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span>
                {currentStep + 1} of {totalSteps}
              </span>
            </div>
            <Progress value={((currentStep + 1) / totalSteps) * 100} className="h-2" />
          </div>
          <div className="flex justify-between">
            <Button variant="outline" onClick={onPrev}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous
            </Button>
            <Button onClick={onNext} disabled={!formData.description.trim()}>
              Next
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// Question 5: TAM with Smart AI Guidance
export const TAMModal = ({
  isOpen,
  onClose,
  onNext,
  onPrev,
  formData,
  updateFormData,
  currentStep,
  totalSteps,
}: QuestionModalProps) => {
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const calculateTAM = async () => {
    setIsLoading(true)
    try {
      // Data checks
      if (!formData.sector || !formData.sector.length) {
        toast({
          title: "Missing Industry Sector",
          description: "Please select your industry sector before calculating TAM.",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }
      if (!formData.businessModel) {
        toast({
          title: "Missing Business Model",
          description: "Please select your business model before calculating TAM.",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }
      if (!formData.description) {
        toast({
          title: "Missing Company Description",
          description: "Please provide a company description before calculating TAM.",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }
      const industry = formData.sector[0]
      const businessModel = formData.businessModel
      const description = formData.description

      const response = await fetch("/api/ai-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: `Calculate the Total Addressable Market (TAM) for a ${businessModel} ${industry} company: "${description}". Return only the market size number and unit (billions or millions) in this exact format: "X.X billions" or "X.X millions".`,
          context: `TAM calculation for ${industry} ${businessModel} startup`,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        // Extract number from response
        const match = data.response.match(/(\d+(?:\.\d+)?)\s*(billion|million|trillion)/i)
        if (match) {
          const value = Number.parseFloat(match[1])
          const unit = match[2].toLowerCase()

          if (unit === "trillion") {
            updateFormData("tam", value * 1000)
            updateFormData("tamUnit", "billions")
          } else {
            updateFormData("tam", value)
            updateFormData("tamUnit", unit === "billion" ? "billions" : "millions")
          }

          toast({
            title: "TAM Calculated",
            description: `Market size estimated at $${value} ${unit}.`,
          })
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not calculate market size.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Total Addressable Market (TAM)
          </DialogTitle>
          <DialogDescription>How big is the total market for your solution?</DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4 py-4">
            <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
              <p className="text-sm text-blue-800 dark:text-blue-200">
                💡 <strong>TAM</strong> represents the total revenue opportunity if you captured 100% of your market.
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <Label htmlFor="tam">Market Size</Label>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={calculateTAM}
                  disabled={isLoading || !formData.sector.length}
                  className="text-primary bg-transparent"
                >
                  {isLoading ? (
                    <>
                      <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                      Calculating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Ask AI to calculate TAM
                    </>
                  )}
                </Button>
              </div>

              <div className="flex gap-2">
                <Input
                  id="tam"
                  type="number"
                  value={formData.tam || ""}
                  onChange={(e) => updateFormData("tam", Number.parseFloat(e.target.value) || 0)}
                  placeholder="Enter market size"
                  className="flex-1"
                />
                <Select
                  value={formData.tamUnit}
                  onValueChange={(value: "billions" | "millions") => updateFormData("tamUnit", value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="billions">Billions</SelectItem>
                    <SelectItem value="millions">Millions</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.tam > 0 && (
                <div className="text-center p-2 bg-muted rounded-lg">
                  <span className="text-lg font-semibold">
                    ${formData.tam} {formData.tamUnit === "billions" ? "Billion" : "Million"}
                  </span>
                </div>
              )}
            </div>
          </div>
        </ScrollArea>

        <div className="flex-shrink-0 space-y-4 pt-4 border-t">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span>
                {currentStep + 1} of {totalSteps}
              </span>
            </div>
            <Progress value={((currentStep + 1) / totalSteps) * 100} className="h-2" />
          </div>
          <div className="flex justify-between">
            <Button variant="outline" onClick={onPrev}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous
            </Button>
            <Button onClick={onNext} disabled={!formData.tam || formData.tam <= 0}>
              Next
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// Question 6: SAM Modal with Smart Guidance
export const SAMModal = ({
  isOpen,
  onClose,
  onNext,
  onPrev,
  formData,
  updateFormData,
  currentStep,
  totalSteps,
}: QuestionModalProps) => {
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const calculateSAM = async () => {
    setIsLoading(true)
    try {
      // Data checks
      if (!formData.tam) {
        toast({
          title: "Missing TAM",
          description: "Please calculate or enter TAM before calculating SAM.",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }
      if (!formData.businessModel) {
        toast({
          title: "Missing Business Model",
          description: "Please select your business model before calculating SAM.",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }
      if (!formData.sector || !formData.sector.length) {
        toast({
          title: "Missing Industry Sector",
          description: "Please select your industry sector before calculating SAM.",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }
      const response = await fetch("/api/ai-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: `If TAM is $${formData.tam} ${formData.tamUnit}, calculate a realistic SAM for a ${formData.businessModel} ${formData.sector[0]} startup. Return only the number and unit in format: "X.X billions" or "X.X millions".`,
          context: `SAM calculation based on TAM of $${formData.tam} ${formData.tamUnit}`,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        const match = data.response.match(/(\d+(?:\.\d+)?)\s*(billion|million)/i)
        if (match) {
          const value = Number.parseFloat(match[1])
          const unit = match[2].toLowerCase()

          updateFormData("sam", value)
          updateFormData("samUnit", unit === "billion" ? "billions" : "millions")

          toast({
            title: "SAM Calculated",
            description: `Serviceable market estimated at $${value} ${unit}.`,
          })
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not calculate SAM.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Serviceable Addressable Market (SAM)
          </DialogTitle>
          <DialogDescription>What portion of the TAM can you realistically target?</DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4 py-4">
            <div className="p-4 bg-green-50 dark:bg-green-950 rounded-lg">
              <p className="text-sm text-green-800 dark:text-green-200">
                💡 <strong>SAM</strong> is the portion of TAM you can serve with your current business model and
                geographic reach.
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <Label htmlFor="sam">Serviceable Market Size</Label>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={calculateSAM}
                  disabled={isLoading || !formData.tam}
                  className="text-primary bg-transparent"
                >
                  {isLoading ? (
                    <>
                      <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                      Calculating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Ask AI to calculate SAM
                    </>
                  )}
                </Button>
              </div>

              <div className="flex gap-2">
                <Input
                  id="sam"
                  type="number"
                  value={formData.sam || ""}
                  onChange={(e) => updateFormData("sam", Number.parseFloat(e.target.value) || 0)}
                  placeholder="Enter serviceable market size"
                  className="flex-1"
                />
                <Select
                  value={formData.samUnit}
                  onValueChange={(value: "billions" | "millions") => updateFormData("samUnit", value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="billions">Billions</SelectItem>
                    <SelectItem value="millions">Millions</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.sam > 0 && (
                <div className="text-center p-2 bg-muted rounded-lg">
                  <span className="text-lg font-semibold">
                    ${formData.sam} {formData.samUnit === "billions" ? "Billion" : "Million"}
                  </span>
                </div>
              )}
            </div>
          </div>
        </ScrollArea>

        <div className="flex-shrink-0 space-y-4 pt-4 border-t">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span>
                {currentStep + 1} of {totalSteps}
              </span>
            </div>
            <Progress value={((currentStep + 1) / totalSteps) * 100} className="h-2" />
          </div>
          <div className="flex justify-between">
            <Button variant="outline" onClick={onPrev}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous
            </Button>
            <Button onClick={onNext} disabled={!formData.sam || formData.sam <= 0}>
              Next
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// Question 7: SOM Modal with Smart Guidance
export const SOMModal = ({
  isOpen,
  onClose,
  onNext,
  onPrev,
  formData,
  updateFormData,
  currentStep,
  totalSteps,
}: QuestionModalProps) => {
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const calculateSOM = async () => {
    setIsLoading(true)
    try {
      // Data checks
      if (!formData.sam) {
        toast({
          title: "Missing SAM",
          description: "Please calculate or enter SAM before calculating SOM.",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }
      if (!formData.sector || !formData.sector.length) {
        toast({
          title: "Missing Industry Sector",
          description: "Please select your industry sector before calculating SOM.",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }
      const response = await fetch("/api/ai-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: `If SAM is $${formData.sam} ${formData.samUnit}, calculate a realistic SOM (market share we can capture) for a startup in ${formData.sector[0]}. Return only the number and unit in format: "X.X billions" or "X.X millions".`,
          context: `SOM calculation based on SAM of $${formData.sam} ${formData.samUnit}`,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        const match = data.response.match(/(\d+(?:\.\d+)?)\s*(billion|million)/i)
        if (match) {
          const value = Number.parseFloat(match[1])
          const unit = match[2].toLowerCase()

          updateFormData("som", value)
          updateFormData("somUnit", unit === "billion" ? "billions" : "millions")

          toast({
            title: "SOM Calculated",
            description: `Obtainable market estimated at $${value} ${unit}.`,
          })
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not calculate SOM.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Serviceable Obtainable Market (SOM)
          </DialogTitle>
          <DialogDescription>What market share can you realistically capture?</DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4 py-4">
            <div className="p-4 bg-purple-50 dark:bg-purple-950 rounded-lg">
              <p className="text-sm text-purple-800 dark:text-purple-200">
                💡 <strong>SOM</strong> is the portion of SAM you can realistically capture given competition and
                resources.
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <Label htmlFor="som">Obtainable Market Size</Label>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={calculateSOM}
                  disabled={isLoading || !formData.sam}
                  className="text-primary bg-transparent"
                >
                  {isLoading ? (
                    <>
                      <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                      Calculating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Ask AI to calculate SOM
                    </>
                  )}
                </Button>
              </div>

              <div className="flex gap-2">
                <Input
                  id="som"
                  type="number"
                  value={formData.som || ""}
                  onChange={(e) => updateFormData("som", Number.parseFloat(e.target.value) || 0)}
                  placeholder="Enter obtainable market size"
                  className="flex-1"
                />
                <Select
                  value={formData.somUnit}
                  onValueChange={(value: "billions" | "millions") => updateFormData("somUnit", value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="billions">Billions</SelectItem>
                    <SelectItem value="millions">Millions</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.som > 0 && (
                <div className="text-center p-2 bg-muted rounded-lg">
                  <span className="text-lg font-semibold">
                    ${formData.som} {formData.somUnit === "billions" ? "Billion" : "Million"}
                  </span>
                </div>
              )}
            </div>
          </div>
        </ScrollArea>

        <div className="flex-shrink-0 space-y-4 pt-4 border-t">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span>
                {currentStep + 1} of {totalSteps}
              </span>
            </div>
            <Progress value={((currentStep + 1) / totalSteps) * 100} className="h-2" />
          </div>
          <div className="flex justify-between">
            <Button variant="outline" onClick={onPrev}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous
            </Button>
            <Button onClick={onNext} disabled={!formData.som || formData.som <= 0}>
              Next
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// Question 8: Revenue Model
export const RevenueModelModal = ({
  isOpen,
  onClose,
  onNext,
  onPrev,
  formData,
  updateFormData,
  currentStep,
  totalSteps,
}: QuestionModalProps) => (
  <Dialog open={isOpen} onOpenChange={onClose}>
    <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
      <DialogHeader className="flex-shrink-0">
        <DialogTitle className="flex items-center gap-2">
          <DollarSign className="h-5 w-5" />
          Revenue Model
        </DialogTitle>
        <DialogDescription>How will your company generate revenue?</DialogDescription>
      </DialogHeader>

      <ScrollArea className="flex-1 pr-4">
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Revenue Models * (Select all that apply)</Label>
            <div className="grid grid-cols-2 gap-3">
              {revenueModels.map((model) => (
                <div key={model} className="flex items-center space-x-2 p-2 rounded-lg hover:bg-muted/50">
                  <Checkbox
                    id={model}
                    checked={formData.revenueModel.includes(model)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        updateFormData("revenueModel", [...formData.revenueModel, model])
                      } else {
                        updateFormData(
                          "revenueModel",
                          formData.revenueModel.filter((r) => r !== model),
                        )
                      }
                    }}
                  />
                  <Label htmlFor={model} className="text-sm cursor-pointer">
                    {model}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="pricing">Average Revenue Per User (ARPU) - Monthly $</Label>
            <Input
              id="pricing"
              type="number"
              value={formData.pricing || ""}
              onChange={(e) => updateFormData("pricing", Number.parseFloat(e.target.value) || 0)}
              placeholder="Enter monthly ARPU"
            />
          </div>
        </div>
      </ScrollArea>

      <div className="flex-shrink-0 space-y-4 pt-4 border-t">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Progress</span>
            <span>
              {currentStep + 1} of {totalSteps}
            </span>
          </div>
          <Progress value={((currentStep + 1) / totalSteps) * 100} className="h-2" />
        </div>
        <div className="flex justify-between">
          <Button variant="outline" onClick={onPrev}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Previous
          </Button>
          <Button onClick={onNext} disabled={formData.revenueModel.length === 0}>
            Next
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </DialogContent>
  </Dialog>
)

// Question 9: Unit Economics
export const UnitEconomicsModal = ({
  isOpen,
  onClose,
  onNext,
  onPrev,
  formData,
  updateFormData,
  currentStep,
  totalSteps,
}: QuestionModalProps) => {
  const [showAIModal, setShowAIModal] = useState(false)

  const handleAICalculation = (calculatedData: { cac: number; ltv: number; grossMargin: number }) => {
    updateFormData("cac", calculatedData.cac)
    updateFormData("ltv", calculatedData.ltv)
    updateFormData("grossMargin", calculatedData.grossMargin)
  }

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-lg max-h-[90vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Unit Economics
            </DialogTitle>
            <DialogDescription>What are your key customer metrics?</DialogDescription>
          </DialogHeader>

          <ScrollArea className="flex-1 pr-4 max-h-[60vh]">
            <div className="space-y-4 py-4">
              <div className="flex justify-end">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAIModal(true)}
                  className="text-primary bg-transparent"
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  Ask AI to calculate Unit Economics
                </Button>
              </div>

              <div className="space-y-2">
                <Label htmlFor="cac">Customer Acquisition Cost (CAC) - $</Label>
                <Input
                  id="cac"
                  type="number"
                  value={formData.cac || ""}
                  onChange={(e) => updateFormData("cac", Number.parseFloat(e.target.value) || 0)}
                  placeholder="Enter CAC in dollars"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="ltv">Customer Lifetime Value (LTV) - $</Label>
                <Input
                  id="ltv"
                  type="number"
                  value={formData.ltv || ""}
                  onChange={(e) => updateFormData("ltv", Number.parseFloat(e.target.value) || 0)}
                  placeholder="Enter LTV in dollars"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="grossMargin">Gross Margin - %</Label>
                <Input
                  id="grossMargin"
                  type="number"
                  value={formData.grossMargin || ""}
                  onChange={(e) => updateFormData("grossMargin", Number.parseFloat(e.target.value) || 0)}
                  placeholder="Enter gross margin percentage"
                />
              </div>

              {formData.cac > 0 && formData.ltv > 0 && (
                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-sm font-medium">LTV:CAC Ratio</p>
                  <p className="text-2xl font-bold text-primary">{(formData.ltv / formData.cac).toFixed(1)}:1</p>
                  <p className="text-xs text-muted-foreground">
                    {formData.ltv / formData.cac >= 3 ? "✅ Healthy ratio" : "⚠️ Should be 3:1 or higher"}
                  </p>
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="flex-shrink-0 space-y-4 pt-4 border-t">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>
                  {currentStep + 1} of {totalSteps}
                </span>
              </div>
              <Progress value={((currentStep + 1) / totalSteps) * 100} className="h-2" />
            </div>
            <div className="flex justify-between">
              <Button variant="outline" onClick={onPrev}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Previous
              </Button>
              <Button onClick={onNext} disabled={!formData.cac || !formData.ltv}>
                Next
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <UnitEconomicsAIModal
        isOpen={showAIModal}
        onClose={() => setShowAIModal(false)}
        onCalculate={handleAICalculation}
      />
    </>
  )
}

// Question 10: Financial Projections
export const FinancialProjectionsModal = ({
  isOpen,
  onClose,
  onNext,
  onPrev,
  formData,
  updateFormData,
  currentStep,
  totalSteps,
}: QuestionModalProps) => {
  const [showTermsModal, setShowTermsModal] = useState(false)

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-lg max-h-[90vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Financial Projections
            </DialogTitle>
            <DialogDescription>What are your financial projections?</DialogDescription>
          </DialogHeader>

          <ScrollArea className="flex-1 pr-4 max-h-[60vh]">
            <div className="space-y-4 py-4">
              <div className="flex justify-end">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowTermsModal(true)}
                  className="text-primary bg-transparent"
                >
                  <Info className="mr-2 h-4 w-4" />
                  Explain Financial Terms
                </Button>
              </div>

              <div className="space-y-2">
                <Label htmlFor="burnRate">Monthly Burn Rate - $</Label>
                <Input
                  id="burnRate"
                  type="number"
                  value={formData.burnRate || ""}
                  onChange={(e) => updateFormData("burnRate", Number.parseFloat(e.target.value) || 0)}
                  placeholder="Enter monthly burn rate"
                />
                <p className="text-xs text-muted-foreground">
                  How much money you spend each month to operate your business
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="runway">Current Runway - Months</Label>
                <Input
                  id="runway"
                  type="number"
                  value={formData.runway || ""}
                  onChange={(e) => updateFormData("runway", Number.parseFloat(e.target.value) || 0)}
                  placeholder="Enter runway in months"
                />
                <p className="text-xs text-muted-foreground">How many months you can operate with current cash</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="fundingNeeded">Funding Needed - $</Label>
                <Input
                  id="fundingNeeded"
                  type="number"
                  value={formData.fundingNeeded || ""}
                  onChange={(e) => updateFormData("fundingNeeded", Number.parseFloat(e.target.value) || 0)}
                  placeholder="Enter funding amount needed"
                />
                <p className="text-xs text-muted-foreground">Total investment required to reach your next milestone</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="useOfFunds">Use of Funds</Label>
                <Textarea
                  id="useOfFunds"
                  value={formData.useOfFunds}
                  onChange={(e) => updateFormData("useOfFunds", e.target.value)}
                  placeholder="Describe how you'll use the funding..."
                  rows={3}
                />
              </div>
            </div>
          </ScrollArea>

          <div className="flex-shrink-0 space-y-4 pt-4 border-t">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>
                  {currentStep + 1} of {totalSteps}
                </span>
              </div>
              <Progress value={((currentStep + 1) / totalSteps) * 100} className="h-2" />
            </div>
            <div className="flex justify-between">
              <Button variant="outline" onClick={onPrev}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Previous
              </Button>
              <Button onClick={onNext}>
                Complete
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <FinancialTermsModal isOpen={showTermsModal} onClose={() => setShowTermsModal(false)} />
    </>
  )
}
