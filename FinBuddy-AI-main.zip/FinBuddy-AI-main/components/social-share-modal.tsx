"use client"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { Copy, Facebook, Twitter, Linkedin, Mail, MessageSquare, Share2, ExternalLink } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"

interface SocialShareModalProps {
  isOpen: boolean
  onClose: () => void
  shareUrl: string
  companyName: string
}

export function SocialShareModal({ isOpen, onClose, shareUrl, companyName }: SocialShareModalProps) {
  const { toast } = useToast()

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl)
      toast({
        title: "Copied!",
        description: "Share link copied to clipboard.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard.",
        variant: "destructive",
      })
    }
  }

  const shareOptions = [
    {
      name: "Copy Link",
      icon: Copy,
      action: copyToClipboard,
      color: "bg-gray-500 hover:bg-gray-600",
    },
    {
      name: "WhatsApp",
      icon: MessageSquare,
      action: () =>
        window.open(`https://wa.me/?text=Check out ${companyName}'s financial model: ${shareUrl}`, "_blank"),
      color: "bg-green-500 hover:bg-green-600",
    },
    {
      name: "Twitter",
      icon: Twitter,
      action: () =>
        window.open(
          `https://twitter.com/intent/tweet?text=Check out ${companyName}'s financial model&url=${shareUrl}`,
          "_blank",
        ),
      color: "bg-blue-400 hover:bg-blue-500",
    },
    {
      name: "LinkedIn",
      icon: Linkedin,
      action: () => window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${shareUrl}`, "_blank"),
      color: "bg-blue-600 hover:bg-blue-700",
    },
    {
      name: "Facebook",
      icon: Facebook,
      action: () => window.open(`https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`, "_blank"),
      color: "bg-blue-500 hover:bg-blue-600",
    },
    {
      name: "Email",
      icon: Mail,
      action: () =>
        window.open(
          `mailto:?subject=${companyName} Financial Model&body=Check out this financial model: ${shareUrl}`,
          "_blank",
        ),
      color: "bg-red-500 hover:bg-red-600",
    },
  ]

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="h-5 w-5" />
            Share Your Financial Model
          </DialogTitle>
          <DialogDescription>Share your financial model with investors and stakeholders</DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh] pr-2">
          <div className="space-y-4">
            {/* Share URL */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Share Link</label>
              <div className="flex gap-2">
                <Input value={shareUrl} readOnly className="flex-1" />
                <Button size="icon" variant="outline" onClick={copyToClipboard}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Social Share Options */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Share On</label>
              <div className="grid grid-cols-2 gap-3">
                {shareOptions.map((option, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    onClick={option.action}
                    className={`justify-start ${option.color} text-white border-0`}
                  >
                    <option.icon className="mr-2 h-4 w-4" />
                    {option.name}
                  </Button>
                ))}
              </div>
            </div>

            {/* Preview Link */}
            <div className="pt-4 border-t">
              <Button variant="outline" className="w-full bg-transparent" onClick={() => window.open(shareUrl, "_blank")}>
                <ExternalLink className="mr-2 h-4 w-4" />
                Preview Shared Model
              </Button>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}
