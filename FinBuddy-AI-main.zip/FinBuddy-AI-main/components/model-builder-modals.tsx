"use client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AIAssistant } from "@/components/ai-assistant"
import { ArrowLeft, ArrowRight, Building2, DollarSign, Target } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"

interface FormData {
  companyName: string
  sector: string[]
  businessModel: string
  description: string
  tam: number
  tamUnit: "billions" | "millions"
  sam: number
  samUnit: "billions" | "millions"
  som: number
  somUnit: "billions" | "millions"
  marketDescription: string
  revenueModel: string[]
  pricing: number
  unitEconomics: string
  cac: number
  ltv: number
  grossMargin: number
  burnRate: number
  fundingNeeded: number
  runway: number
  useOfFunds: string
}

const initialFormData: FormData = {
  companyName: "",
  sector: [],
  businessModel: "",
  description: "",
  tam: 0,
  tamUnit: "billions",
  sam: 0,
  samUnit: "billions",
  som: 0,
  somUnit: "millions",
  marketDescription: "",
  revenueModel: [],
  pricing: 0,
  unitEconomics: "",
  cac: 0,
  ltv: 0,
  grossMargin: 0,
  burnRate: 0,
  fundingNeeded: 0,
  runway: 0,
  useOfFunds: "",
}

const industries = [
  "FinTech",
  "HealthTech",
  "EdTech",
  "E-commerce",
  "SaaS",
  "Marketplace",
  "AI/ML",
  "Blockchain",
  "IoT",
  "Cybersecurity",
  "Gaming",
  "Social Media",
  "Food & Beverage",
  "Transportation",
  "Real Estate",
  "Energy",
  "Agriculture",
  "Other",
]

const revenueModels = [
  "Subscription (SaaS)",
  "Transaction Fees",
  "Marketplace Commission",
  "Advertising",
  "Freemium",
  "One-time Purchase",
  "Licensing",
  "Affiliate Marketing",
]

interface ModalStepProps {
  isOpen: boolean
  onClose: () => void
  onNext: () => void
  onPrev: () => void
  formData: FormData
  updateFormData: (field: keyof FormData, value: any) => void
  currentStep: number
  totalSteps: number
}

const CompanyInfoModal = ({ isOpen, onClose, onNext, formData, updateFormData }: ModalStepProps) => (
  <Dialog open={isOpen} onOpenChange={onClose}>
    <DialogContent className="max-w-2xl">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Building2 className="h-5 w-5" />
          Company Information
        </DialogTitle>
        <DialogDescription>Tell us about your company and what you do</DialogDescription>
      </DialogHeader>

      <ScrollArea className="flex-1 max-h-[60vh] pr-2">
        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="companyName">Company Name *</Label>
            <Input
              id="companyName"
              value={formData.companyName}
              onChange={(e) => updateFormData("companyName", e.target.value)}
              placeholder="Enter your company name"
            />
          </div>

          <div className="space-y-2">
            <Label>Industry Sectors * (Select all that apply)</Label>
            <div className="grid grid-cols-3 gap-2 max-h-40 overflow-y-auto">
              {industries.map((industry) => (
                <div key={industry} className="flex items-center space-x-2">
                  <Checkbox
                    id={industry}
                    checked={formData.sector.includes(industry)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        updateFormData("sector", [...formData.sector, industry])
                      } else {
                        updateFormData(
                          "sector",
                          formData.sector.filter((s) => s !== industry),
                        )
                      }
                    }}
                  />
                  <Label htmlFor={industry} className="text-sm">
                    {industry}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Business Model *</Label>
            <RadioGroup value={formData.businessModel} onValueChange={(value) => updateFormData("businessModel", value)}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="b2b" id="b2b" />
                <Label htmlFor="b2b">B2B (Business to Business)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="b2c" id="b2c" />
                <Label htmlFor="b2c">B2C (Business to Consumer)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="b2b2c" id="b2b2c" />
                <Label htmlFor="b2b2c">B2B2C (Business to Business to Consumer)</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Company Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => updateFormData("description", e.target.value)}
              placeholder="Describe what your company does, the problem you solve, and your solution"
              rows={4}
            />
          </div>
        </div>
      </ScrollArea>

      <div className="flex justify-between pt-4">
        <Button variant="outline" disabled>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Previous
        </Button>
        <Button onClick={onNext} disabled={!formData.companyName || !formData.sector.length || !formData.businessModel}>
          Next
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </DialogContent>
    <AIAssistant
      context="company information and business model setup"
      placeholder="Ask me about business models, industry selection, or company descriptions..."
      showTag={true}
      tagText="Ask AI"
    />
  </Dialog>
)

const MarketSizingModal = ({ isOpen, onClose, onNext, onPrev, formData, updateFormData }: ModalStepProps) => (
  <Dialog open={isOpen} onOpenChange={onClose}>
    <DialogContent className="max-w-2xl">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Target className="h-5 w-5" />
          Market Sizing
        </DialogTitle>
        <DialogDescription>Define your total addressable market and opportunity size</DialogDescription>
      </DialogHeader>

      <ScrollArea className="flex-1 max-h-[60vh] pr-2">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="tam">Total Addressable Market (TAM)</Label>
              <Select
                value={formData.tamUnit}
                onValueChange={(value: "billions" | "millions") => updateFormData("tamUnit", value)}
              >
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="billions">Billions</SelectItem>
                  <SelectItem value="millions">Millions</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Input
                type="number"
                value={formData.tam || ""}
                onChange={(e) => updateFormData("tam", Number.parseFloat(e.target.value) || 0)}
                placeholder={`Enter TAM in ${formData.tamUnit}`}
              />
              <div className="text-center text-sm text-muted-foreground">
                ${formData.tam} {formData.tamUnit === "billions" ? "B" : "M"}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="sam">Serviceable Addressable Market (SAM)</Label>
              <Select
                value={formData.samUnit}
                onValueChange={(value: "billions" | "millions") => updateFormData("samUnit", value)}
              >
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="billions">Billions</SelectItem>
                  <SelectItem value="millions">Millions</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Input
                type="number"
                value={formData.sam || ""}
                onChange={(e) => updateFormData("sam", Number.parseFloat(e.target.value) || 0)}
                placeholder={`Enter SAM in ${formData.samUnit}`}
              />
              <div className="text-center text-sm text-muted-foreground">
                ${formData.sam} {formData.samUnit === "billions" ? "B" : "M"}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="som">Serviceable Obtainable Market (SOM)</Label>
              <Select
                value={formData.somUnit}
                onValueChange={(value: "billions" | "millions") => updateFormData("somUnit", value)}
              >
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="billions">Billions</SelectItem>
                  <SelectItem value="millions">Millions</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Input
                type="number"
                value={formData.som || ""}
                onChange={(e) => updateFormData("som", Number.parseFloat(e.target.value) || 0)}
                placeholder={`Enter SOM in ${formData.somUnit}`}
              />
              <div className="text-center text-sm text-muted-foreground">
                ${formData.som} {formData.somUnit === "billions" ? "B" : "M"}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="marketDescription">Market Description</Label>
            <Textarea
              id="marketDescription"
              value={formData.marketDescription}
              onChange={(e) => updateFormData("marketDescription", e.target.value)}
              placeholder="Describe your target market, competition, and market trends"
              rows={4}
            />
          </div>
        </div>
      </ScrollArea>

      <div className="flex justify-between pt-4">
        <Button variant="outline" onClick={onPrev}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Previous
        </Button>
        <Button onClick={onNext}>
          Next
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </DialogContent>
    <AIAssistant
      context="market sizing - TAM, SAM, SOM calculations"
      placeholder="Ask me about market sizing, TAM vs SAM vs SOM, or market research..."
      showTag={true}
      tagText="Ask AI"
    />
  </Dialog>
)

const RevenueModelModal = ({ isOpen, onClose, onNext, onPrev, formData, updateFormData }: ModalStepProps) => (
  <Dialog open={isOpen} onOpenChange={onClose}>
    <DialogContent className="max-w-2xl">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <DollarSign className="h-5 w-5" />
          Revenue Model
        </DialogTitle>
        <DialogDescription>How will your company generate revenue?</DialogDescription>
      </DialogHeader>

      <ScrollArea className="flex-1 max-h-[60vh] pr-2">
        <div className="space-y-6">
          <div className="space-y-2">
            <Label>Revenue Models * (Select all that apply)</Label>
            <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto">
              {revenueModels.map((model) => (
                <div key={model} className="flex items-center space-x-2">
                  <Checkbox
                    id={model}
                    checked={formData.revenueModel.includes(model)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        updateFormData("revenueModel", [...formData.revenueModel, model])
                      } else {
                        updateFormData(
                          "revenueModel",
                          formData.revenueModel.filter((r) => r !== model),
                        )
                      }
                    }}
                  />
                  <Label htmlFor={model} className="text-sm">
                    {model}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="pricing">Average Revenue Per User (ARPU) - Monthly $</Label>
            <div className="relative">
              <Input
                id="pricing"
                type="number"
                value={formData.pricing || ""}
                onChange={(e) => updateFormData("pricing", Number.parseFloat(e.target.value) || 0)}
                placeholder="Enter monthly ARPU"
              />
              <Button
                variant="ghost"
                size="sm"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 text-xs"
                onClick={() => updateFormData("pricing", 0)}
              >
                Clear
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="unitEconomics">Unit Economics Description</Label>
            <Textarea
              id="unitEconomics"
              value={formData.unitEconomics}
              onChange={(e) => updateFormData("unitEconomics", e.target.value)}
              placeholder="Explain how you calculate revenue per customer, including any key metrics"
              rows={3}
            />
          </div>
        </div>
      </ScrollArea>

      <div className="flex justify-between pt-4">
        <Button variant="outline" onClick={onPrev}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Previous
        </Button>
        <Button onClick={onNext} disabled={!formData.revenueModel.length}>
          Next
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </DialogContent>
    <AIAssistant
      context="revenue models and pricing strategy"
      placeholder="Ask me about revenue models, ARPU calculations, or unit economics..."
      showTag={true}
      tagText="Ask AI"
    />
  </Dialog>
)

export { CompanyInfoModal, MarketSizingModal, RevenueModelModal }
export type { FormData }
